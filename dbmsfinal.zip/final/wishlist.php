<?php
	// Include the functions page for common functions.
	include_once("includes/common_functions.php");

	// Create a connection to the database
	$connect = connection();

	// If the user is logged in then assign the username variable from session info.
	session_start();
	$username = $_SESSION['user'];

	$result=mysqli_query( $connect, "SELECT uid FROM Users WHERE Email = '".$username."'") or die("Could not execute query: " .mysqli_error($connect));

	 while($row = mysqli_fetch_assoc($result)) {
	    $userID = $row['uid'];
	  }

	 $userID = mysqli_real_escape_string($connect, $userID);

  // Free the results
  mysqli_free_result($result);

	//Get the isbn if sent over from the books or books profile page.
	if ($_GET) {
			$isbn = $_GET['isbn'];
      $isbn = mysqli_real_escape_string($connect, $isbn);
	}

?>
<!DOCTYPE html>
<html>
	<head>
		<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
		<title> Favorite Page</title>
	</head>
	<body>
		<img class="logo" src="images/logo.PNG"/>
	  <nav class="navbar navbar-default">
	  <div class="container">
	    <div class="navbar-header">
	      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
	        <span class="icon-bar"></span>
	        <span class="icon-bar"></span>
	        <span class="icon-bar"></span>
	      </button>
	    </div>
	    <div class="collapse navbar-collapse" id="myNavbar">
	      <ul class="nav navbar-nav navbar-right">
					<li id="home"><a href="home.php">Home</a></li>
	        <li id="books"><a href="books.php">Search Books</a></li>
	        <li id="favorites"><a href="favorites.php">Favorites</a></li>
            <li id="cart"><a href="cart.php">Cart</a></li>
	        <li id="orders"><a href="orders.php">Orders</a></li>
	        <li id="Logout"><a href="logout.php">Logout</a></li>
	      </ul>
	    </div>
	  </div>
	</nav>
		<br>
		<br>
    <div class="container">
    <table class="table" style="border-radius:5px;width:50%;margin:0px auto;float:none;text-align:center">
      <thead>
        <tr><th style="text-align:center">My Wishlist</th></tr>
      </thead>
		<?php
        //Get the isbn if sent over from the books or books profile page.
        if(isset($_GET['isbn'])) {
            // Query to check if the row exists in the wishlists table
    				$query="SELECT * FROM wishlists";
    				$query.=" WHERE uid = '{$userID}' AND isbn = '{$isbn}';";

    				// Perform the database query
    				$result1 = mysqli_query($connect, $query);

    				// If the query failed, then kill the database and output the failure.
    				if (!$result1) {
    					printf("DB Failed: %s\n", mysqli_error($connect));
    					die("row exist query failed.");

    				} else {

    					// Count the rows returned.
    					$count = mysqli_num_rows($result1);

    					if ($count == 0) {

                // Free the results
        				mysqli_free_result($result1);

    						// Insert into the wishlists table appropriate values.
    						$query="INSERT INTO wishlists";
    						$query.=" (uid, isbn)";
    						$query.=" VALUES ('{$userID}', '{$isbn}');";

    						// Perform the database query
    						$result2 = mysqli_query($connect, $query);

    						// If the query failed, then kill the database and output the failure.
    						if (!$result2) {
    							printf("DB Failed: %s\n", mysqli_error($connect));
    							die("Insert failed.");

    						}

              }
                //Query to grab all the books the user favorited
                $allquery="SELECT DISTINCT b.isbn, b.title, b.image FROM books b LEFT JOIN wishlists w";
                $allquery.=" ON b.isbn = w.isbn LEFT JOIN users u ON u.uid = w.uid WHERE w.uid='{$userID}';";
                //echo '<pre>'.$allquery.'</pre>';

                $result3 = mysqli_query($connect, $allquery);
                ini_set('memory_limit', '-1');

                // If the query failed, then kill the database and output the failure.
    						if (!$result3) {
    							printf("DB Failed: %s\n", mysqli_error($connect));
    							die("Favorite query failed.");

                } else {

                  echo '<tbody>';
                  // If it did not fail then loop through the results and add the values in the table.
        					while($row=mysqli_fetch_assoc($result3)) {
                    $isb = $row['isbn'];
                    echo '<tr><td>';
                    //Both the image and title is a link to the book profile page with the isbn sent as a parameter.
                    echo '<br><a href="bookprofile.php?isbn='.$isb.  '"><img src="'.$row['image'].'"></a><br>';
                    echo 'Title: <a href="bookprofile.php?isbn='.$isb.'">'.$row['title'].'</a><br>';
                    echo 'ISBN: '.$isb.'<br>';
                    echo '<a href="editwishlist.php?isbn='.$isb.'">Remove</a><br>';
                    ?>
                    </td></tr>
                  <?php } ?>
                  </tbody>
                  </table>
                  </div>
                </body>
              </html>
                  <?php
              // Free the results
              mysqli_free_result($result3);
    					}
          }
        //Even if no isbn was sent over/clicked on wishlists link at the nav bar
        } else {
          //Query to grab all the books the user favorited
          $allquery="SELECT DISTINCT b.isbn, b.title, b.image FROM books b LEFT JOIN wishlists w";
          $allquery.=" ON b.isbn = w.isbn LEFT JOIN users u ON u.uid = w.uid WHERE w.uid='{$userID}';";
          //echo '<pre>'.$allquery.'</pre>';

          $result3 = mysqli_query($connect, $allquery);
          ini_set('memory_limit', '-1');

          // If the query failed, then kill the database and output the failure.
          if (!$result3) {
            printf("DB Failed: %s\n", mysqli_error($connect));
            die("Favorite query failed.");

          } else {

            echo '<tbody>';
            // If it did not fail then loop through the results and add the values in the table.
            while($row=mysqli_fetch_assoc($result3)) {
              $isb = $row['isbn'];
              echo '<tr><td>';
              //Both the image and title is a link to the book profile page with the isbn sent as a parameter.
              echo '<br><a href="bookprofile.php?isbn='.$isb.  '"><img src="'.$row['image'].'"></a><br>';
              echo 'Title: <a href="bookprofile.php?isbn='.$isb.'">'.$row['title'].'</a><br>';
              echo 'ISBN: '.$row["isbn"].'<br><br>';
              echo '<a href="editwishlist.php?isbn='.$isb.'">Remove</a><br>';
              ?>
              </td></tr>
            <?php   }?>
            </tbody>
            </table>
            </div>
          </body>
        </html>
            <?php
        // Free the results
        mysqli_free_result($result3);
        }
      }
        // Close the db connection.
        mysqli_close($connect);
    		?>
