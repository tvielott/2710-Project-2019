<?php
  // Include the functions page for common functions.
  include_once("includes/common_functions.php");

  // Create a connection to the database
  $connect = connection();

  // If the user is logged in then assign the username variable from session info.
  session_start();
  $username = $_SESSION['user'];


  $result=mysqli_query( $connect, "SELECT uid FROM Users WHERE Email = '".$username."'") or die("Could not execute query: " .mysqli_error($connect));

   while($row = mysqli_fetch_assoc($result)) {
      $userID = $row['uid'];
    }
    $userID = mysqli_real_escape_string($connect, $userID);

?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <title>Book Leaf | Order History</title>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1"/>
    <link rel="stylesheet" type="text/css" href="style/styles.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  </head>
  <body>
    <img class="logo" src="images/logo.PNG"/>
    <nav class="navbar navbar-default">
      <div class="container">
        <div class="navbar-header">
          <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
        </div>
        <div class="collapse navbar-collapse" id="myNavbar">
          <ul class="nav navbar-nav navbar-right">
            <li id="books"><a href="books.php">Search Books</a></li>
            <li id="favorites"><a href="favorites.php">Favorites</a></li>
            <li id="wishlist"><a href="wishlist.php">Wishlist</a></li>
             <li id="cart"><a href="cart.php">Cart</a></li>
            <li id="Logout"><a href="logout.php">Logout</a></li>
          </ul>
        </div>
      </div>
    </nav>
    <div class="container-fluid bg-3 text-center">
    <div class="row">
      <div class="col-sm-4" style="margin-top:15px">
      </div>
      <div class="col-sm-4" style="text-align:left; margin-top:15px">
        <table class="table table-bordered">
          <thead style="align:center">
            <tr>
              <th scope="col">Order History</th>
            </tr>
          </thead>
          <tbody style="text-align:center">
            <?php
                $query = "SELECT o.completed, o.oid, o.order_date, o.shipped_date, s.sname FROM orders o LEFT JOIN stores s ON o.sid = s.sid WHERE o.uid = '$userID' ORDER BY o.order_date DESC";
                $res = mysqli_query($connect, $query);
                //echo '<pre>'.$query.'</pre>';
                if(!$res){
                  printf("DB Failed: %s\n", mysqli_error($connect));
                  die("Order query failed.");
                }
                while($row = mysqli_fetch_assoc($res)) {
                    $completed = $row['completed'];
                    if($completed == 0){
                      $completed = 'Processing';
                    } else {
                      $completed = 'Completed';
                    }
                    $order_date = $row['order_date'];
                    $ship_date = ($row['shipped_date'] == '' ? 'Not Yet Shipped' : $row['shipped_date']);

                    $store = $row['sname'];
                    $oid = $row['oid'];

                    echo '<tr><td>';
                    echo '<strong>Order ID: '.$oid.'</strong><br>';
                    echo 'Order Date: '.$order_date.'<br>';
                    echo 'Shipped Date: '.$ship_date.'<br>';
                    echo 'Store: '.$store.'<br>';

                    $getbooks = "SELECT DISTINCT ob.isbn, ob.price_at_sale, ob.units, b.image, b.title FROM orders_books ob LEFT JOIN books b ON b.isbn = ob.isbn WHERE ob.oid = '$oid'";
                    $res1 = mysqli_query($connect, $getbooks);

                    if(!$res1){
                      printf("DB Failed: %s\n", mysqli_error($connect));
                      die("Order query failed.");
                    }
                    $total = 0;
                    while($row = mysqli_fetch_assoc($res1)) {
                      $isbn = $row['isbn'];
                      $unit = $row['units'];
                      $price = $row['price_at_sale'];
                      $title = $row['title'];
                      $image = $row['image'];
                      $total = $total + ($price*$unit) ;

                      echo '<br><a href="bookprofile.php?isbn='.$isbn.  '"><img src="'.$image.'"></a><br>';
                      echo 'Title: <a href="bookprofile.php?isbn='.$isbn.'">'.$title.'</a><br>';
                      echo 'Units: '.$unit.'<br>';
                      echo 'Price Per Unit: $'.$price.'<br>';
                    }
                    echo '<br><em>Total: $'.$total.'</em><br>';
                    echo 'Status: '.$completed.'<br>';

                    ?>
                    </td></tr>
                  <?php } ?>
                          </tbody>
                          </table>
                          </div>
                        </body>
                      </html>
