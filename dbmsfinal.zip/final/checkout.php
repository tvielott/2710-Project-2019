<?php
if($_POST){
  // Include the functions page for common functions.
  include_once("includes/common_functions.php");

  // Create a connection to the database
  $connect = connection();

  // If the user is logged in then assign the username variable from session info.
  session_start();
  $username = $_SESSION['user'];


  $result=mysqli_query( $connect, "SELECT uid FROM Users WHERE Email = '".$username."'") or die("Could not execute query: " .mysqli_error($connect));

   while($row = mysqli_fetch_assoc($result)) {
      $userID = $row['uid'];
    }

  $userID = mysqli_real_escape_string($connect, $userID);

}
else{
  header('location:cart.php');
}

 ?>

 <!DOCTYPE html>
 <html>
 	<head>
 		<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
     <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
 		<link rel="stylesheet" href="style/checkout.css">
     <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
 		<title> Favorite Page</title>
 	</head>
 	<body>
 		<img class="logo" src="images/logo.PNG"/>
 	  <nav class="navbar navbar-default">
 	  <div class="container">
 	    <div class="navbar-header">
 	      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
 	        <span class="icon-bar"></span>
 	        <span class="icon-bar"></span>
 	        <span class="icon-bar"></span>
 	      </button>
 	    </div>
 	    <div class="collapse navbar-collapse" id="myNavbar">
 	      <ul class="nav navbar-nav navbar-right">
 					<li id="home"><a href="home.php">Home</a></li>
 	        <li id="books"><a href="books.php">Search Books</a></li>
 	        <li id="favorites"><a href="favorites.php">Favorites</a></li>
             <li id="wishlist"><a href="wishlist.php">Wishlist</a></li>
 	        <li id="orders"><a href="orders.php">Orders</a></li>
 	        <li id="Logout"><a href="logout.php">Logout</a></li>
 	      </ul>
 	    </div>
 	  </div>
 	</nav>
 		<br>
 		<br>
     <div class="container">

<div class="container wrapper">
           <div class="row cart-head">
               <div class="container">
               <div class="row">
                   <p></p>
               </div>
               <div class="row">
                   <div style="display: table; margin: auto;">

                       <span class="step step_complete"> <a href="#" class="check-bc">Checkout</a> <span class="step_line "> </span> <span class="step_line step_complete"> </span> </span>

                   </div>
               </div>
               <div class="row">
                   <p></p>
               </div>
               </div>
           </div>
           <div class="row ">
               <form class="form-horizontal" method="post" action="payment.php">
               <div class="col-lg-3 col-md-3 col-sm-3 col-xs-12 col-md-push-3 col-sm-push-3">

               </div>
               <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12 col-md-pull-6 col-sm-pull-6" style="position: inherit;">
                   <!--SHIPPING METHOD-->
                   <div class="panel panel-info">
                       <div class="panel-heading">Address</div>
                       <div class="panel-body">
                           <div class="form-group">
                               <div class="col-md-12">
                                   <h4>Shipping Address</h4>
                               </div>
                           </div>

                           <div class="form-group">
                               <div class="col-md-12"><strong>Address:</strong></div>
                               <div class="col-md-12">
                                   <input type="text" name="address" class="form-control" value="" required/>
                               </div>
                           </div>
                           <div class="form-group">
                               <div class="col-md-12"><strong>City:</strong></div>
                               <div class="col-md-12">
                                   <select id="CreditCardType" name="city" class="form-control">
                                     <?php
                                        $city_sel = "SELECT * FROM Cities";
                                        $qry_city = mysqli_query($connect,$city_sel);
                                        while($row = mysqli_fetch_assoc($qry_city)){
                                      ?>
                                       <option value="<?php echo $row['cname']; ?>"><?php echo $row['cname']; ?></option>
                                       <?php
                                     }
                                        ?>
                                   </select>
                               </div>
                           </div>
                           <div class="form-group">
                               <div class="col-md-12"><strong>State:</strong></div>
                               <div class="col-md-12">
                                 <select name="state" class="form-control">
                                   <?php
                                      $city_sel = "SELECT * FROM Cities";
                                      $qry_city = mysqli_query($connect,$city_sel);
                                      while($row = mysqli_fetch_assoc($qry_city)){
                                    ?>
                                     <option value="<?php echo $row['state']; ?>"><?php echo $row['state']; ?></option>
                                     <?php
                                   }
                                      ?>
                                 </select>
                               </div>
                           </div>
                           <div class="form-group">
                               <div class="col-md-12"><strong>Zip / Postal Code:</strong></div>
                               <div class="col-md-12">
                                   <input type="text" name="zip" class="form-control" value="" required/>
                               </div>
                           </div>
                           <div class="form-group">
                               <div class="col-md-12"><strong>Payment Method:</strong></div>
                               <div class="col-md-12">
                                   <select id="CreditCardType" name="payment_type" class="form-control">
                                       <option value="cod">Cod</option>
                                   </select>
                               </div>
                           </div>
                           <div class="form-group">
                             <div class="col-md-5 col-sm-5 col-xs-12">

                             </div>
                               <div class="col-md-6 col-sm-6 col-xs-12">
                                   <button type="submit" class="btn btn-primary btn-submit-fix">Place Order</button>
                               </div>
                           </div>
                       </div>
                   </div>
                   <!--SHIPPING METHOD END-->

               </div>

               </form>
           </div>
           <div class="row cart-footer">

           </div>
   </div>


     </div>
           </body>
         </html>
