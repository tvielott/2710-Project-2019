<?php
    session_start();
    $fName = $_SESSION['fname'];
    $lName = $_SESSION['lname'];
    $employeeid = $_SESSION['eid'];
    $email = $_SESSION['email'];
    $password = $_SESSION['password'];
    // Include the functions page for common functions.
    include_once("includes/common_functions.php");

    // Create a connection to the database
    $conn = connection();

    $result=mysqli_query( $conn, "SELECT * FROM Employees, Users WHERE Email = '".$email."' AND Password = '".$password."' AND Employees.uid = Users.uid") or die("Could not execute query: " .mysqli_error($conn));
    $row = mysqli_fetch_assoc($result);

  	if($row == ""){
      echo "Unauthorized Access!";
  		header("refresh:3; url=index.html");
  		exit;
  	}
 ?>

<!DOCTYPE html>
<html lang="en">
<head>
<title>Admin | User Management</title>
<meta charset="utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1"/>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>

<style>
.active{
  color: black;
  font-weight: bold;
}

.table{
  width: 80%;
  margin: 0 auto;
}

.table_frame{
  margin-top: 20px;
}

.link:hover{
  color: grey;
  text-decoration: none;
}

.link{
  position:relative;
  top:15px;
  left: 1380px;
}

</style>
</head>
<body>
  <img class="logo" src="images/logo.PNG"/>
  <nav class="navbar navbar-default">
    <!-- the options changes depending on what page the user is on-->
    <div class="collapse navbar-collapse" id="myNavbar">
      <ul class="nav navbar-nav navbar-right">
        <li id="User"><a class="active" href="admin_user_manage.php">Users</a></li>
        <li id="Book"><a href="admin_book_manage.php">Books</a></li>
        <li id="Transaction"><a href="admin_transaction_manage.php">Transactions</a></li>
        <li id="Sales_Report"><a href="admin_sales_report.php">Sales Report&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</a></li>
        <li><a style="color: red;"><?php echo $fName." ".$lName." (eid:".$employeeid.")";?></a></li>
        <li id="Logout"><a href="logout.php">Logout</a></li>
      </ul>
    </div>
  </nav>

  <a class="link" href="./create_user_page.php">Create a new user</a>

<div class="table_frame">  <table class="table">
    <thead>
      <tr>
        <th>UID</th>
        <th>First Name</th>
        <th>Last Name</th>
        <th>Email</th>
        <th>Phone</th>
        <th> </th>
      </tr>
    </thead>

<?php
  $result = mysqli_query( $conn, "SELECT * FROM Users") or die("Could not execute query: " .mysqli_error($conn));
  echo "<tbody>";
  while ($row = mysqli_fetch_row($result)){

?>
    <tr>
      <td><?php echo $row[0]?></td>
      <td><?php echo $row[1]?></td>
      <td><?php echo $row[2]?></td>
      <td><?php echo $row[3]?></td>
      <td><?php echo $row[5]?></td>
      <td><a href="./user_edit.php?uid=<?php echo $row[0]?>">Edit</a></td>
    </tr>


<?php
  }
  echo "</tbody></table></div>";
?>



</body>

</html>
