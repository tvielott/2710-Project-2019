<?php
  // Include the functions page for common functions.
  include_once("includes/common_functions.php");

  // Create a connection to the database
  $connect = connection();

  // If the user is logged in then assign the username variable from session info.
  session_start();
  $username = $_SESSION['user'];


  $result=mysqli_query( $connect, "SELECT uid FROM Users WHERE Email = '".$username."'") or die("Could not execute query: " .mysqli_error($connect));

   while($row = mysqli_fetch_assoc($result)) {
      $userID = $row['uid'];
    }
    $userID = mysqli_real_escape_string($connect, $userID);

  // Free the results
  mysqli_free_result($result);

      $isbn = $_POST['isbn'];
      $isbn = mysqli_real_escape_string($connect, $isbn);
      $rating = $_POST['rating'];
      $review = $_POST['review'];

      //check if the user already rated the book first
      $checkq = "SELECT * FROM ratings WHERE isbn = '{$isbn}' AND uid='{$userID}';";
      $result = mysqli_query($connect, $checkq);

      // If the query failed, then kill the database and output the failure.
      if (!$result) {
        printf("DB Failed: %s\n", mysqli_error($connect));
        die("Database query failed.");
        echo "Remove favorite query error";
      } else {
        // Count the rows returned.
        $count = mysqli_num_rows($result);

        //if there are no rows returned, insert the rating/review
        if ($count == 0) {

          // Free the results
          mysqli_free_result($result);

          $query = "INSERT INTO ratings (uid, isbn, rating, review)";
          $query.= " VALUES ('{$userID}','{$isbn}', '{$rating}', '{$review}');";

          // Perform the database query
          $result = mysqli_query($connect, $query);

          // If the query failed, then kill the database and output the failure.
          if (!$result) {
            printf("DB Failed: %s\n", mysqli_error($connect));
            die("Database query failed.");
            echo "Remove favorite query error";
          } else {
              header("Location: bookprofile.php?isbn={$isbn}");
          }
      //Otherwise don't insert and return to the bookprofile page
      } else {
          header("Location: bookprofile.php?isbn={$isbn}");
      }
    }


?>
