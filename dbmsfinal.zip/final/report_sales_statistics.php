<?php
    // Include the functions page for common functions.
    include_once("includes/common_functions.php");

    // Create a connection to the database
    $conn = connection();
    session_start();
    $fName = $_SESSION['fname'];
    $lName = $_SESSION['lname'];
    $employeeid = $_SESSION['eid'];
    $email = $_SESSION['email'];
    $password = $_SESSION['password'];

    $result=mysqli_query( $conn, "SELECT * FROM Employees, Users WHERE Email = '".$email."' AND Password = '".$password."' AND Employees.uid = Users.uid") or die("Could not execute query: " .mysqli_error($conn));
    $row = mysqli_fetch_assoc($result);

  	if($row == ""){
      echo "Unauthorized Access!";
  		header("refresh:3; url=index.html");
  		exit;
  	}

 ?>

<!DOCTYPE html>
<html lang="en">
<head>
<title>Admin | Sales Report</title>
<meta charset="utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1"/>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>

<style>
.active{
  color: black;
  font-weight: bold;
}

.table{
  margin: auto;
  width: 60%;
}

button{

  border: solid 1px grey;
}
</style>
</head>
<body>
  <img class="logo" src="images/logo.PNG"/>
  <nav class="navbar navbar-default">
    <!-- the options changes depending on what page the user is on-->
    <div class="collapse navbar-collapse" id="myNavbar">
      <ul class="nav navbar-nav navbar-right">
        <li id="User"><a href="admin_user_manage.php">Users</a></li>
        <li id="Book"><a href="admin_book_manage.php">Books</a></li>
        <li id="Transaction"><a href="admin_transaction_manage.php">Transactions</a></li>
        <li id="Sales_Report"><a class="active" href="admin_sales_report.php">Sales Report&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</a></li>
        <li><a style="color: red;"><?php echo $fName." ".$lName." (eid:".$employeeid.")";?></a></li>
        <li id="Logout"><a href="logout.php">Logout</a></li>
      </ul>
    </div>
  </nav>

<?php
  $result2 = mysqli_query( $conn, "SELECT Orders_books.isbn, Books.price, sum(Orders_books.units) as 'Total Sale', (sum(Orders_books.units*Orders_books.price_at_sale)-sum(Orders_books.units*Books.price)) as Profit
                                    FROM Orders_books, Books
                                    WHERE Orders_books.isbn = Books.isbn
                                    GROUP BY Orders_books.isbn") or die("Could not execute query: " .mysqli_error($conn));
  if($result2){
?>
        <table class="table">
          <thead>
            <tr>
              <th>ISBN</th>
              <th>Price</th>
              <th>Total sale</th>
              <th>Profit</th>
            </tr>
          </thead>
<?php
  }
  echo "<tbody>";
  while ($row2 = mysqli_fetch_row($result2)){
?>
          <tbody>
            <tr>
              <td><?php echo $row2[0]?></td>
              <td><?php echo $row2[1]?></td>
              <td><?php echo $row2[2]?></td>
              <td><?php echo $row2[3]?></td>
            </tr>
          </tbody>
<?php
  }
  echo "</tbody></table>";
?>
      </div>

</body>

</html>
