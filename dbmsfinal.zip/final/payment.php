<?php
if($_POST){
  // Include the functions page for common functions.
  include_once("includes/common_functions.php");

  // Create a connection to the database
  $connect = connection();
  $cid = mt_rand(1000,9999);
  $aid = mt_rand(1000,9999);
  $oid = mt_rand(10100,99999);

  // If the user is logged in then assign the username variable from session info.
  session_start();
  $username = $_SESSION['user'];

  $result=mysqli_query( $connect, "SELECT uid FROM Users WHERE Email = '".$username."'") or die("Could not execute query: " .mysqli_error($connect));

   while($row = mysqli_fetch_assoc($result)) {
      $userID = $row['uid'];
    }

   $userID = mysqli_real_escape_string($connect, $userID);


  $payment_type = $_POST['payment_type'];
  if($payment_type == 'cod'){
    $street = $_POST['address'];
    $city = trim($_POST['city']);
    $state = trim($_POST['state']);
    $zip = $_POST['zip'];

    $findcity = "SELECT cid from cities where cname = '{$city}' and state = '{$state}'";
    $result = mysqli_query($connect,$findcity);

    if (!$result) {
      printf("DB Failed: %s\n", mysqli_error($connect));
      die("Address query failed.");
    } else {
      if(mysqli_num_rows($result) == 1){
        while($row = mysqli_fetch_assoc($result)) {
           $cid = $row['cid'];
         }
      }else{
        $insertadd = "INSERT INTO cities (cname, state) VALUES ('{$city}', '{$state}')";
        $res = mysqli_query($connect,$insertadd);
        if(!$res){
          printf("DB Failed: %s\n", mysqli_error($connect));
          die("Insert address query failed.");
        }
        }
      }

      mysqli_free_result($result);
  }
    //Insert into address table the shipping address
    $insert = "INSERT INTO addresses (aid, uid, street,cid,zip) VALUES ('$aid','$userID','$street','$cid','$zip')";
    $result1 = mysqli_query($connect,$insert);
    echo '<pre>'.$insert.'</pre>';

    $date = date('Y-m-d');

    //Insert the order into the orders table. SID = 0 since it's online
    $query = "INSERT INTO orders (oid, uid, aid, eid, order_date, sid, completed) VALUES ('$oid', '$userID', '$aid', '0', '$date','0', '0')";
    echo '<pre>'.$query.'</pre>';
    $res = mysqli_query($connect, $query);
    // Check that the query did not fail.
    if (!$res) {
      printf("DB Failed: %s\n", mysqli_error($connect));
      die("Database query failed.");

  }

    $sel_d = "SELECT * FROM Cart WHERE uid = '$userID'";
    $qrys = mysqli_query($connect,$sel_d);
    while($row = mysqli_fetch_assoc($qrys)){
      $isbn = $row['isbn'];
      $qty = $row['qty'];
      $booksq = "SELECT * FROM Books WHERE isbn = '{$isbn}'";
      $booksq = mysqli_query($connect,$booksq);
      $books = mysqli_fetch_assoc($booksq);
      $price = $books['price'];

      $ins = "INSERT INTO Orders_Books (oid, isbn,units,price_at_sale) VALUES ('$oid', '$isbn','$qty','$price')";
      echo "<pre> ".$ins."</pre>";
      $res2 = mysqli_query($connect, $ins);
      while(!$res2){
        printf("DB Failed: %s\n", mysqli_error($connect));
        die("Database query failed.");
      }

      $qry_books = "SELECT * FROM Books WHERE isbn = '{$isbn}'";
      $qrys_books = mysqli_query($connect,$qry_books);
      $books = mysqli_fetch_assoc($qrys_books);

      $main_qty = $books['quantity_avail'] - $qty;
      $update = "UPDATE Books SET quantity_avail = $main_qty WHERE isbn = '$isbn'";
      mysqli_query($connect,$update);

    }


        $del_qry = "DELETE FROM Cart WHERE uid = '$userID'";
        mysqli_query($connect,$del_qry);
        header('location:cart.php?order=success');

    }
    else{
      header('location:cart.php');
    }

 ?>
