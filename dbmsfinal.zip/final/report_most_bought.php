<?php
    // Include the functions page for common functions.
    include_once("includes/common_functions.php");

    // Create a connection to the database
    $conn = connection();
    session_start();
    $fName = $_SESSION['fname'];
    $lName = $_SESSION['lname'];
    $employeeid = $_SESSION['eid'];
    $email = $_SESSION['email'];
    $password = $_SESSION['password'];

    $result=mysqli_query( $conn, "SELECT * FROM Employees, Users WHERE Email = '".$email."' AND Password = '".$password."' AND Employees.uid = Users.uid") or die("Could not execute query: " .mysqli_error($conn));
    $row = mysqli_fetch_assoc($result);

  	if($row == ""){
      echo "Unauthorized Access!";
  		header("refresh:3; url=index.html");
  		exit;
  	}

 ?>

<!DOCTYPE html>
<html lang="en">
<head>
<title>Admin | Sales Report</title>
<meta charset="utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1"/>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>

<style>
.active{
  color: black;
  font-weight: bold;
}

.form{
  margin-top: 50px;
  margin-left:650px;
}

.display{
  margin: auto;
  width: 50%;
}

h1{
  font-size:25px;
}

button{

  border: solid 1px grey;
}
</style>
</head>
<body>
  <img class="logo" src="images/logo.PNG"/>
  <nav class="navbar navbar-default">
    <!-- the options changes depending on what page the user is on-->
    <div class="collapse navbar-collapse" id="myNavbar">
      <ul class="nav navbar-nav navbar-right">
        <li id="User"><a href="admin_user_manage.php">Users</a></li>
        <li id="Book"><a href="admin_book_manage.php">Books</a></li>
        <li id="Transaction"><a href="admin_transaction_manage.php">Transactions</a></li>
        <li id="Sales_Report"><a class="active" href="admin_sales_report.php">Sales Report&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</a></li>
        <li><a style="color: red;"><?php echo $fName." ".$lName." (eid:".$employeeid.")";?></a></li>
        <li id="Logout"><a href="logout.php">Logout</a></li>
      </ul>
    </div>
  </nav>

  <form class="form" action="report_most_bought.php" method="post">
    <div class="form-row">
      <div class="form-group col-md-3">
        <label>ISBN = </label>
        <input type="text" name="isbn" required>
      </div>
      <div class="form-group  col-md-3">
        <button type="submit" class="btn btn-primary">Search</button>
      </div>
    </div>
  </form>
  <br><br>

  <?php
      if (isset($_POST['isbn'])){
        $isbn=($_POST['isbn']);
      }
      else{
        $isbn = "xxx";
      }

      $result2 = mysqli_query( $conn, "SELECT Users.uid, Users.email, Users.fName, Users.lName, SUM(Orders_books.units)
                                FROM Orders_books, Orders, Users
                                WHERE Orders_books.oid = Orders.oid
                                AND Orders.uid = Users.uid
                                AND Orders_books.isbn = '".$isbn."'
                                GROUP BY USERS.uid
                                HAVING SUM(Orders_books.units) = (
                                    SELECT SUM(Orders_books.units) AS MAX
                                    FROM Orders_books, Orders, Users
                                    WHERE Orders_books.oid = Orders.oid
                                    AND Orders.uid = Users.uid
                                    AND Orders_books.isbn = '".$isbn."'
                                    GROUP BY USERS.uid
                                    ORDER BY MAX DESC
                                    LIMIT 1
                                )") or die("Could not execute query: " .mysqli_error($conn));
     if($result2){
  ?>
  <div class="display">
      <h1>ISBN: <?php echo $isbn ?></h1>
      <br>
      <table class="table">
        <thead class="thead-dark">
          <tr>
            <th>User ID</th>
            <th>Email</th>
            <th>First Name</th>
            <th>Last Name</th>
            <th>Amount</th>
          </tr>
        </thead>

    <?php
        }
        echo "<tbody>";
        while ($row2 = mysqli_fetch_row($result2)){
    ?>
        <tbody>
        <tr>
          <td><?php echo $row2[0]; ?></td>
          <td><?php echo $row2[1]; ?></td>
          <td><?php echo $row2[2]; ?></td>
          <td><?php echo $row2[3]; ?></td>
          <td><?php echo $row2[4]; ?></td>
        </tr>
        </tbody>
      </div>
  <?php
      }
  ?>

</body>

</html>
