<?php
    // Include the functions page for common functions.
    include_once("includes/common_functions.php");

    // Create a connection to the database
    $conn = connection();
    session_start();
    $fName = $_SESSION['fname'];
    $lName = $_SESSION['lname'];
    $employeeid = $_SESSION['eid'];
    $email = $_SESSION['email'];
    $password = $_SESSION['password'];

    $result=mysqli_query( $conn, "SELECT * FROM Employees, Users WHERE Email = '".$email."' AND Password = '".$password."' AND Employees.uid = Users.uid") or die("Could not execute query: " .mysqli_error($conn));
    $row = mysqli_fetch_assoc($result);

  	if($row == ""){
      echo "Unauthorized Access!";
  		header("refresh:3; url=index.html");
  		exit;
  	}

    $isbn = $_GET["isbn"];
    $result=mysqli_query( $conn, "SELECT * FROM Books WHERE isbn = '".$isbn."'") or die("Could not execute query: " .mysqli_error($conn));
    $row = mysqli_fetch_assoc($result);
 ?>

<!DOCTYPE html>
<html lang="en">
<head>
<title>Admin | Book Management</title>
<meta charset="utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1"/>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>

<style>
.active{
  color: black;
  font-weight: bold;
}

.form{
  width: 80%;
  margin: 0 auto;
}

.table{
  width: 60%;
}

button{
  border: solid 1px grey;
}
</style>
</head>
<body>
  <img class="logo" src="images/logo.PNG"/>
  <nav class="navbar navbar-default">
    <!-- the options changes depending on what page the user is on-->
    <div class="collapse navbar-collapse" id="myNavbar">
      <ul class="nav navbar-nav navbar-right">
        <li id="User"><a href="admin_user_manage.php">Users</a></li>
        <li id="Book"><a class="active" href="admin_book_manage.php">Books</a></li>
        <li id="Transaction"><a href="admin_transaction_manage.php">Transactions</a></li>
        <li id="Sales_Report"><a href="admin_sales_report.php">Sales Report&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</a></li>
        <li><a style="color: red;"><?php echo $fName." ".$lName." (eid:".$employeeid.")";?></a></li>
        <li id="Logout"><a href="logout.php">Logout</a></li>
      </ul>
    </div>
  </nav>

  <form action="./update_book.php?isbn=<?php echo $row['isbn']?>" id="book_form" class="form" method="post">
      <div style="font-size:25px;margin-bottom:20px;"> ISBN<bold>: <?php echo $row['isbn']?> </div>

      <div class="form-group row">
          <label for="title" class="col-sm-2 col-form-label">Book Title:</label>
          <input type="text" class="form-control col-sm-10" id="title" name="title" maxlength="500" value="<?php echo $row['title']?>" required>
      </div>
      <div class="form-group row">
          <label for="price" class="col-sm-2 col-form-label">Price:</label>
          <input type="number" class="form-control col-sm-10" id="price" name="price" maxlength="50" value="<?php echo $row['price']?>" required>
      </div>
      <div class="form-group row">
          <label for="inventory" class="col-sm-2 col-form-label">Inventory:</label>
          <input type="number" class="form-control col-sm-10" id="inventory" name="inventory" maxlength="11" value="<?php echo $row['quantity_avail']?>" >
      </div>
      <div class="form-group row">
          <label for="image" class="col-sm-2 col-form-label">Image:</label>
          <input type="text" class="form-control col-sm-10" id="image" name="image" maxlength="250" value="<?php echo $row['image']?>" >
      </div>
      <div class="form-group row">
<?php
  $result2 = mysqli_query( $conn, "SELECT Authors.name, Publishers.pname, Genres.gname FROM Authors, Publishers, Genres, Books, Books_genres, Books_authors WHERE Books.isbn = '".$isbn."' AND Books.pubid = Publishers.pubid AND Books.isbn = Books_authors.isbn AND Books_authors.auid = Authors.auid AND Books.isbn = Books_genres.isbn AND Books_genres.gid = Genres.gid") or die("Could not execute query: " .mysqli_error($conn));
  if($result2){
?>
        <label for="information" class="col-sm-2 col-form-label">Book's information:</label>
        <table class="table">
          <thead>
            <tr>
              <th>Author</th>
              <th>Publisher</th>
              <th>Genre</th>
            </tr>
          </thead>
<?php
  }
  echo "<tbody>";
  while ($row2 = mysqli_fetch_row($result2)){
?>
          <tbody>
            <tr>
              <th><?php echo $row2[0]?></th>
              <th><?php echo $row2[1]?></th>
              <th><?php echo $row2[2]?></th>
            </tr>
          </tbody>
<?php
  }
  echo "</tbody></table>";
?>
      </div>
      <div class="form-group">
          <button type="submit" class="btn btn-secondary">Update</button>
          <a href="./delete_book.php?isbn=<?php echo $row['isbn']?>" class="btn btn-secondary">Delete</button>
      </div>
  </form>

</body>

</html>
