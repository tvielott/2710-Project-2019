<?php
  // Include the functions page for common functions.
  include_once("includes/common_functions.php");

  // Create a connection to the database
  $connect = connection();

  // If the user is logged in then assign the username variable from session info.
  session_start();
  $username = $_SESSION['user'];

  $result=mysqli_query( $connect, "SELECT uid, fName FROM Users WHERE Email = '".$username."'") or die("Could not execute query: " .mysqli_error($connect));

   while($row = mysqli_fetch_assoc($result)) {
      $userID = $row['uid'];
      $name = $row['fName'];
    }

   $userID = mysqli_real_escape_string($connect, $userID);

   $query="SELECT * FROM ratings";
   $query.=" WHERE uid = '{$userID}';";
   //echo '<pre>'.$query.'</pre>';

   // Perform the database query
    $result = mysqli_query($connect, $query);

    // If the query failed, then kill the database and output the failure.
    if (!$result) {
      printf("DB Failed: %s\n", mysqli_error($connect));
      die("row exist query failed.");
    } else {
      // Count the rows returned.
      $count = mysqli_num_rows($result);
    }
?>
<!DOCTYPE html>
<html lang="en">
<head>
<title>Book Leaf | Home</title>
<meta charset="utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1"/>
<link rel="stylesheet" type="text/css" href="style/styles.css">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
</head>
<body>
  <img class="logo" src="images/logo.PNG"/>
  <nav class="navbar navbar-default">
  <div class="container">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
      </button>
    </div>
    <div class="collapse navbar-collapse" id="myNavbar">
      <ul class="nav navbar-nav navbar-right">
        <li id="books"><a href="books.php">Search Books</a></li>
        <li id="favorites"><a href="favorites.php">Favorites</a></li>
        <li id="wishlist"><a href="wishlist.php">Wishlist</a></li>
        <li id="cart"><a href="cart.php">Cart</a></li>
        <li id="orders"><a href="orders.php">Orders</a></li>
        <li id="Logout"><a href="logout.php">Logout</a></li>
      </ul>
    </div>
  </div>
</nav>
  <div class="container-fluid bg-3 text-center">
  <h1>Welcome <?php echo $name;?>!</h1>
  <div class="row">
    <div class="col-sm-4">

      </div>
    <div class="col-sm-4" style="margin-top:5em">
    <table class="table table-sm table-dark" style="border: 1px solid black;font-size:.8em">
        <thead>
          <tr>
            <th scope="col" style="text-align:center">Your Ratings</th>
          </tr>
        </thead>
        <tbody>
          <?php
              if($count == 0){
                echo "<tr><td>";
                echo "You haven't rated any books yet.</td></tr>";
              } else {
                //Query to grab all the books the user rated
                $allquery="SELECT DISTINCT b.isbn, b.title, b.image, r.rating, r.review FROM books b LEFT JOIN ratings r";
                $allquery.=" ON b.isbn = r.isbn LEFT JOIN users u ON u.uid = r.uid WHERE r.uid='{$userID}';";
                //echo '<pre>'.$allquery.'</pre>';

                $res= mysqli_query($connect, $allquery);
                if(!$res){
                  printf("DB Failed: %s\n", mysqli_error($connect));
                   die("Rating query failed.");
                }else{
                  while($row=mysqli_fetch_assoc($res)) {
                    $isb = $row['isbn'];
                    echo '<tr><td>';
                    //Both the image and title is a link to the book profile page with the isbn sent as a parameter.
                    echo '<a href="bookprofile.php?isbn='.$isb.'">'.$row['title'].'</a><br>';
                    echo 'ISBN: '.$isb.'<br>';
                    echo 'Rating: '.$row['rating'].'</br>';
                    echo 'Review: '.$row['review'].'</br>';
                    echo '</tr></td>';
                }
              }
            }
           ?>
       </tbody>
     </table>

    </div>
    <div class="col-sm-4">
    </div>
  </div>
</body>
<?php
  // Close the db connection.
    mysqli_close($connect);

?>
</html>
