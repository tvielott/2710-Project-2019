<?php
	// Include the functions page for common functions.
	include_once("includes/common_functions.php");

	// Create a connection to the database
	$connect = connection();

	session_start();
	$username = $_SESSION['user'];

	$result=mysqli_query( $connect, "SELECT uid FROM Users WHERE Email = '".$username."'") or die("Could not execute query: " .mysqli_error($connect));

	 while($row = mysqli_fetch_assoc($result)) {
			$userID = $row['uid'];
		}

	 $userID = mysqli_real_escape_string($connect, $userID);


  //Get the isbn if sent over from the books or books profile page.
	if (isset($_GET['isbn'])) {
			$isbn = $_GET['isbn'];
      $isbn = mysqli_real_escape_string($connect, $isbn);
	}



  // Free the results
  //mysqli_free_result($result);









?>
<!DOCTYPE html>
<html>
	<head>
		<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
		<link rel="stylesheet" href="style/cart.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
		<title> Favorite Page</title>
	</head>
	<body>
		<img class="logo" src="images/logo.PNG"/>
	  <nav class="navbar navbar-default">
	  <div class="container">
	    <div class="navbar-header">
	      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
	        <span class="icon-bar"></span>
	        <span class="icon-bar"></span>
	        <span class="icon-bar"></span>
	      </button>
	    </div>
	    <div class="collapse navbar-collapse" id="myNavbar">
	      <ul class="nav navbar-nav navbar-right">
					<li id="home"><a href="home.php">Home</a></li>
	        <li id="books"><a href="books.php">Search Books</a></li>
	        <li id="favorites"><a href="favorites.php">Favorites</a></li>
            <li id="wishlist"><a href="wishlist.php">Wishlist</a></li>
	        <li id="orders"><a href="orders.php">Orders</a></li>
	        <li id="Logout"><a href="logout.php">Logout</a></li>
	      </ul>
	    </div>
	  </div>
	</nav>
		<br>
		<br>
    <div class="container">
			<h3 style="text-align:center">My cart</h3>
			<table id="cart" class="table table-hover table-condensed">
    				<thead>
						<tr>
							<th style="width:50%">Product</th>
							<th style="width:10%">Price</th>
							<th style="width:8%">Quantity</th>
							<th style="width:22%" class="text-center">Subtotal</th>
							<th style="width:10%"></th>
						</tr>
					</thead>
					<tbody>
						<?php

						if(isset($_GET['action'])){
							$action = $_GET['action'];
						} else {
							$action = '';
						}
						switch ($action) {
							case 'insert':{

										$isbn = $_GET['isbn'];
										$qry_books = "SELECT * FROM Books WHERE isbn = '{$isbn}'";
										$qrys_books = mysqli_query($connect,$qry_books);
										$books = mysqli_fetch_assoc($qrys_books);
										$price = $books['price'];

									if($_GET['qty']){
										$qty = $_GET['qty'];
										$price = $price * $qty;
									}
									else{
										$qty = 1;
										$price = $books['price'];
									}
									echo $qty;

									$avil_qtys = $books['quantity_avail'];
									//print_r($books);
									$get_prds = "SELECT * FROM Cart WHERE uid = '{$userID}' and isbn = '{$isbn}'";
									//echo "<br>";
									$qry_prd = mysqli_query($connect,$get_prds);
									$get_data = mysqli_fetch_array($qry_prd);
								//	print_r($get_data);
									$qty = $get_data['qty'] + $qty;
									if($get_data){
										$prd_ids = $get_data['id'];
										$prices = $get_data['total_price'] + $price;
										$up_qry = "UPDATE Cart SET qty = '$qty',total_price = '$prices' WHERE id = '$prd_ids'";
										mysqli_query($connect,$up_qry);
										header('location:cart.php');
									}
									else{
									 	$ins_qry = "INSERT INTO Cart (`uid`,`isbn`,`qty`,`total_price`) values('$userID','$isbn','$qty','$price')";
										mysqli_query($connect,$ins_qry);
										header('location:cart.php');

									}
									break;
							}
							case 'plus':{
								$isbn = $_GET['isbn'];
								$qry_books = "SELECT * FROM Books WHERE isbn = '{$isbn}'";
								$qrys_books = mysqli_query($connect,$qry_books);
								$books = mysqli_fetch_assoc($qrys_books);

								$price = $books['price'];
								$avil_qtys = $books['quantity_avail'];
								//print_r($books);
								$get_prds = "SELECT * FROM Cart WHERE uid = '{$userID}' and isbn = '{$isbn}'";
								//echo "<br>";
								$qry_prd = mysqli_query($connect,$get_prds);
								$get_data = mysqli_fetch_array($qry_prd);
							//	print_r($get_data);
								$qty = $get_data['qty'] + 1;
								 $prd_ids = $_GET['id'];
								 $prices = $get_data['total_price'] + $price;
								 $up_qry = "UPDATE Cart SET qty = '$qty',total_price = '$prices' WHERE id = '$prd_ids'";
								 mysqli_query($connect,$up_qry);
								 header('location:cart.php');
								 break;
							}

							case 'minus':{
								$isbn = $_GET['isbn'];
								$qry_books = "SELECT * FROM Books WHERE isbn = '{$isbn}'";
								$qrys_books = mysqli_query($connect,$qry_books);
								$books = mysqli_fetch_assoc($qrys_books);

								$price = $books['price'];
								$avil_qtys = $books['quantity_avail'];
								//print_r($books);
								$get_prds = "SELECT * FROM Cart WHERE uid = '{$userID}' and isbn = '{$isbn}'";
								//echo "<br>";
								$prd_ids = $_GET['id'];
								$qry_prd = mysqli_query($connect,$get_prds);
								$get_data = mysqli_fetch_array($qry_prd);
								//echo count($get_data);
								//print_r($get_data);

								if($get_data['qty']==1){
									$up_qry = "DELETE FROM Cart WHERE id = '$prd_ids'";
								}
								else{

								//	print_r($get_data);
									$qty = $get_data['qty'] - 1;

									 $prices = $get_data['total_price'] - $price;
									 $up_qry = "UPDATE Cart SET qty = '$qty',total_price = '$prices' WHERE id = '$prd_ids'";
								}

								 mysqli_query($connect,$up_qry);
								 header('location:cart.php');


								break;
							}




							default:
								// code...
								{







						$allquery="SELECT b.isbn, b.title, b.image,b.quantity_avail, b.price, c.uid,c.id,c.qty,c.total_price FROM books b LEFT JOIN Cart c";
						$allquery.=" ON b.isbn = c.isbn LEFT JOIN users u ON u.uid = c.uid WHERE c.uid='{$userID}';";
						//echo $allquery;
						$result3 = mysqli_query($connect, $allquery);
		        ini_set('memory_limit', '-1');
						if (!$result3) {
		          printf("DB Failed: %s\n", mysqli_error($connect));
		          die("Favorite query failed.");

		        } else {
							$total = 0;
							$count = mysqli_num_rows($result3);
							while($row=mysqli_fetch_assoc($result3)) {

								//print"<pre>";
								//print_r($row);
								//print"</pre>";
								$isb = $row['isbn'];
								$total = $total + $row['total_price'];
								$row_count[] =  $row;
						 ?>

						<tr>
							<td data-th="Product">
								<div class="row">
									<div class="col-sm-2 hidden-xs">
										<?php echo '<a href="bookprofile.php?isbn='.$isb.'">'; ?><img src="<?php echo $row['image']; ?>" style="width: 100px;height: 100px;" alt="..." class="img-responsive"/></a>
									</div>
									<div class="col-sm-10">
										<h4 class="nomargin"><?php echo '<a href="bookprofile.php?isbn='.$isb.'">'.$row['title'].'</a><br>'; ?></h4>
										<p><?php echo 'ISBN: '.$row["isbn"].'<br><br>'; ?></p>
									</div>
								</div>
							</td>
							<td data-th="Price"><?php echo 'Price: <a href="bookprofile.php?isbn='.$isb.'">'.$row['price'].'</a><br>'; ?></td>
							<td data-th="Quantity">
								<div class="row">
									<a href="cart.php?action=minus&isbn=<?php echo $isb; ?>&id=<?php echo $row['id']; ?>" class="col-md-2" style="padding:0;font-size:23px;"> - </a>

									<div class="col-md-6" style="padding:0;"><input type="number" class="form-control text-center" style="width: 45px;padding:0;" disabled value="<?php echo $row['qty']; ?>"></div>
								<a href="
								<?php
								$isbn = $row["isbn"];
								$qry_books = "SELECT * FROM Books WHERE isbn = '{$isbn}'";
								$qrys_books = mysqli_query($connect,$qry_books);
								$books = mysqli_fetch_assoc($qrys_books);
								$books['quantity_avail'];
									if($row['qty']>=$books['quantity_avail']){
										echo "javascript:void(0)";
									}
									else{
								 ?>
								cart.php?action=plus&isbn=<?php echo $isb; ?>&id=<?php echo $row['id']; ?>
								<?php
							}
								 ?>
								" style="padding:0;font-size:23px;" class="col-md-2">+</a></div>
							</td>
							<td data-th="Subtotal" class="text-center"> Sub Total Price: <?php echo $row['total_price']; ?></td>
							<td class="actions" data-th="">

								<?php echo '<a href="editCart.php?id='.$row['id'].'">'; ?><button class="btn btn-danger btn-sm" type="button">Remove</button></td>
							</td>
						</tr>
						<?php

					}
					if($count <1){
						echo "<tr colspan='4' style='text-align:center;'><td style='color:red;text-align:center;'>No Product Found In Your Carts</td></tr>";
					}
				}

				//echo count($row_count);

						 ?>



					</tbody>





					<tfoot>
						<tr class="visible-xs">
							<td class="text-center"><strong>Total
								<?php
										echo $total;

								 ?>

							</strong></td>
						</tr>
						<tr>
							<td><a href="books.php" class="btn btn-warning"><i class="fa fa-angle-left"></i> Continue Shopping</a></td>
							<td colspan="2" class="hidden-xs"></td>
							<td class="hidden-xs text-center" style="<?php if(count($row_count)<1){ echo "display:none;";} ?> "><strong>Total:  <?php
									echo $total;

							 ?></strong></td>
							<td style="<?php if(count($row_count)<1){ echo "display:none;";} ?> ">
								<form action="checkout.php" method="post">
									<input type="hidden" name="total" value="<?php echo $total; ?>">
									<input type="hidden" name="user_id" value="<?php echo $userID; ?>">
									<button class="btn btn-success btn-block">Checkout <i class="fa fa-angle-right"></i></button>
								</form>

							</td>
						</tr>
					</tfoot>
					<?php

				}
					break;
			} ?>
				</table>
				<?php
						if(isset($_GET['order'])){
							echo "<h1 style='color:green;text-align:center;'>Your Order Successfully Placed</h1>";
						}

				 ?>
    </div>
          </body>
        </html>
