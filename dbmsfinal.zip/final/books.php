<?php
  // Include the functions page for common functions.
  include_once("includes/common_functions.php");

  // Create a connection to the database
  $connect = connection();

  // If the user is logged in then assign the username variable from session info.
  session_start();
  $username = $_SESSION['user'];


  $result=mysqli_query( $connect, "SELECT uid FROM Users WHERE Email = '".$username."'") or die("Could not execute query: " .mysqli_error($connect));

   while($row = mysqli_fetch_assoc($result)) {
      $uid = $row['uid'];
    }


  ?>
  <!DOCTYPE html>
  <html lang="en">
  <head>
  <title>Book Leaf | Search</title>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1"/>
  <link rel="stylesheet" type="text/css" href="style/styles.css">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  </head>
  <body>
    <img class="logo" src="images/logo.PNG"/>
    <nav class="navbar navbar-default">
    <div class="container">
      <div class="navbar-header">
        <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
          <span class="icon-bar"></span>
          <span class="icon-bar"></span>
          <span class="icon-bar"></span>
        </button>
      </div>
      <div class="collapse navbar-collapse" id="myNavbar">
        <ul class="nav navbar-nav navbar-right">
          <li id="home"><a href="home.php">Home</a></li>
          <li id="favorites"><a href="favorites.php">Favorites</a></li>
          <li id="wishlist"><a href="wishlist.php">Wishlist</a></li>
          <li id="cart"><a href="cart.php">Cart</a></li>
          <li id="orders"><a href="orders.php">Orders</a></li>
          <li id="Logout"><a href="logout.php">Logout</a></li>
        </ul>
      </div>
    </div>
  </nav>


  			<p align=center>Search Books: </p>

  			<!-- This form shows the filter options for books - all fields are optional-->
  			<form id="filter" method="post" action="books.php" align=center>
    			Title: <input type="text" name="title" placeholder="Title"> &nbsp&nbsp

    			Genre: <select name="genre">
  				<option value="any">Any</option>
  				<option value="Absurdist/surreal/whimsical"> Absurdist</option>
          <option value="Adventure"> Adventure</option>
  				<option value="Action"> Action</option>
          <option value="Comedy"> Comedy</option>
          <option value="Crime"> Crime</option>
          <option value="Drama"> Drama</option>
  				<option value="Fantasy"> Fantasy</option>
          <option value="Historical"> Historical</option>
          <option value="Historical fiction"> Historical Fiction</option>
          <option value="Horror"> Horror</option>
  				<option value="Magical realism"> Magical Realism</option>
  				<option value="Mystery"> Mystery</option>
  				<option value="Paranoid fiction"> Paranoid Fiction</option>
          <option value="Philosophical"> Philosophical</option>
  				<option value="Political"> Political</option>
  				<option value="Romance"> Romance</option>
  				<option value="Saga"> Saga</option>
  				<option value="Satire"> Satire</option>
          <option value="Science fiction"> Science Fiction</option>
  				<option value="Social"> Social</option>
  				<option value="Speculative"> Speculative</option>
  				<option value="Thriller"> Thriller</option>
          <option value="Urban"> Urban</option>
  				<option value="Western"> Western</option>
  				</select>&nbsp &nbsp

  				<input type="submit" name="submit" value="Submit" /><br>
  			</form><br>

  			<div class="center">
  			<!-- Create a table to display the replies-->
  			<table border='1' style="width:80%" align="center">
  				<tr>
  					<th style="text-align:center">Books</th>
  				</tr>
  			<?php

  			if($_POST){

  				// Get the input from the form and trim appropirate inputs.
  				$title = trim($_POST['title']);
  				$genre = array_key_exists('genre', $_POST) ? $_POST['genre'] : null;

  				$genre = mysqli_real_escape_string($connect, $genre);

  				if ($genre == "any") {
  					$genre = "%";
  				}

  				// If the title is empty, then set it to *, otherwise escape it.
  				if (!is_present($title)) {
  					$title = "%";
  				} else {
  					$title = mysqli_real_escape_string($connect, $title);
  				}

  				// Select all from the books table that matches the conditions inputed by user.
  				$query = "SELECT DISTINCT b.isbn, b.title,b.quantity_avail, b.image, b.price FROM books b, genres g, books_genres bg";
  				$query.= " WHERE b.isbn = bg.isbn AND bg.gid =g.gid AND b.title LIKE '{$title}%' AND g.gname LIKE '{$genre}';";

          //echo '<pre>'.$query.'</pre>';
  				// Perform the database query
  				$results = mysqli_query($connect, $query);

  				// If the query failed, then kill the database and output the failure.
  				if (!$results) {
  					printf("DB Failed: %s\n", mysqli_error($connect));
  					die("Database query failed.");

  				} else {

  					// If it did not fail then loop through the results and add the values in the table.
  					if (mysqli_num_rows($results) > 0) {

  						while($row=mysqli_fetch_assoc($results)) {
                $isbn = $row['isbn'];
  						?>
              <td>
                <div class="col-sm-3">
                </div>
                <div class="col-sm-3">
                  <?php
                    //Both the image and title is a link to the book profile page with the isbn sent as a parameter.
                    echo '<br><a href="bookprofile.php?isbn='.$isbn.  '"><img src="'.$row['image'].'"></a><br>';
                    echo 'Title: <a href="bookprofile.php?isbn='.$isbn.'">'.$row['title'].'</a><br>';
                    echo 'Price: $'. $row["price"].'<br>';
                    echo 'ISBN: '.$row["isbn"].'<br>';

                    if($row['quantity_avail'] <1){
                      echo "Quantity: Out Of Stock<br>";
                    }
                    else{
                      echo 'Quantity: '.$row["quantity_avail"].'<br>';
                    }

                  ?>
                </div>
                <div class="col-sm-3" style="text-align:center;margin-top:5%;">
                  <!-- Create a favorites button-->
                  <form action="favorites.php">
                    <input type="submit" value="Favorite" />
                    <input type="hidden" name="isbn" value="<?php echo $row['isbn'];?>"/>
                  </form><br>
                  <!-- Create a wishlist button-->
                  <form action="wishlist.php">
                    <input type="submit" value="Wishlist" />
                    <input type="hidden" name="isbn" value="<?php echo $row['isbn'];?>"/>
                  </form><br>
                </div>
              </div>
              </td>
  						</tr>
  					    <?php
  						}
  					} else {
  						?>
  						<td align="center" font-color="red">
  						No results returned. Try again.
  						</td>
  					<?php
  					}
  				}
  			} else {

  				// Create a query that will retreive values from the books table.
  				$query= "SELECT *";
  				$query.=" FROM `books`";

  				$results = mysqli_query($connect, $query);

  				// Check that the query did not fail.
  				if (!$results) {
  					printf("DB Failed: %s\n", mysqli_error($connect));
  					die("Database query failed.");
  				}
  				else {
  					// If it did not fail then loop through the results and add the values in the table.
  					while($row=mysqli_fetch_assoc($results)) {
              $isbn = $row['isbn'];
  					?>
  								<td>
                    <div class="col-sm-3">
                    </div>
                    <div class="col-sm-3">
                      <?php
                        //Both the image and title is a link to the book profile page with the isbn sent as a parameter.
                        echo '<br><a href="bookprofile.php?isbn='.$isbn.  '"><img src="'.$row['image'].'"></a><br>';
                        echo 'Title: <a href="bookprofile.php?isbn='.$isbn.'">'.$row['title'].'</a><br>';
                        echo 'Price: $'. $row["price"].'<br>';
                        echo 'ISBN: '.$row["isbn"].'<br>';
                        if($row['quantity_avail'] <1){
                          echo "Quantity: Out Of Stock<br>";
                        }
                        else{
                          echo 'Quantity: '.$row["quantity_avail"].'<br>';
                        }
                      ?>
                    </div>
                    <div class="col-sm-3" style="text-align:center;margin-top:5%;">
                      <!-- Create a favorites button-->
                      <form action="favorites.php" >
                        <input type="submit" value="Favorite" />
                        <input type="hidden" name="isbn" value="<?php echo $row['isbn'];?>"/>
                      </form><br>
                      <form action="wishlist.php">
                        <input type="submit" value="Wishlist" />
                        <input type="hidden" name="isbn" value="<?php echo $row['isbn'];?>"/>
                      </form><br>
                    </div>
                  </div>
  								</td>
  							</tr>
  					<?php
  						}
  					}
  			}
  			?>
  	</table>
  	</div>
    <div>
    </div>
  </html>
