<?php
    // Include the functions page for common functions.
    include_once("includes/common_functions.php");

    // Create a connection to the database
    $conn = connection();
    session_start();
    $fName = $_SESSION['fname'];
    $lName = $_SESSION['lname'];
    $employeeid = $_SESSION['eid'];
    $email = $_SESSION['email'];
    $password = $_SESSION['password'];


    $publisherid = mt_rand(100,999);
    $auid = mt_rand(10000,99999);
    $gid = mt_rand(1000,9999);
    $isbn = $_POST["isbn"];
    $title = $_POST["title"];
    $price = $_POST["price"];
    $inventory = $_POST["inventory"];
    $genre = $_POST["genre"];
    $author = $_POST["author"];
    $publisher = $_POST["publisher"];
    $image = $_POST["image"];


    if(strlen($isbn) > 30){
        echo "ISBN maximum length is 30";
        header("refresh:3; url=../create_book_page.php");
        exit;
    } else if(strlen($title) > 500){
        echo "Title maximum length is 500";
        header("refresh:3; url=../create_book_page.php");
        exit;
    } else if(strlen($price) > 50){
        echo "Price maximum length is 50";
        header("refresh:3; url=../create_book_page.php");
        exit;
    } else if (strlen($inventory) > 11) {
        echo "Inventory maximum length is 11";
        header("refresh:3; url=../create_book_page.php");
        exit;
    } else if (strlen($genre) > 45) {
        echo "Genre maximum length is 45";
        header("refresh:3; url=../create_book_page.php");
        exit;
    }else if (strlen($author) > 45) {
        echo "Author maximun length is 45";
        header("refresh:3; url=../create_book_page.php");
        exit;
    }else if (strlen($publisher) > 45) {
        echo "Publisher maximun length is 45";
        header("refresh:3; url=../create_book_page.php");
        exit;
    }else if (strlen($image) > 250) {
        echo "Image maximun length is 250";
        header("refresh:3; url=../create_book_page.php");
        exit;
    }

        if ($conn->connect_error)
        {
            die("Connection failed: " . $conn->connect_error);
        }
// Check if ISBN exists
        $ret=mysqli_query( $conn, "SELECT * FROM Books WHERE isbn = '".$isbn."'") or die("Could not execute query: " .mysqli_error($conn));
        $row1 = mysqli_fetch_assoc($ret);

// Check and insert publisher's information then insert book's information
        if(!$row1){
            $publishercheck=mysqli_query( $conn, "SELECT * FROM Publishers WHERE pname = '".$publisher."'") or die("Could not execute query: " .mysqli_error($conn));
            $row2 = mysqli_fetch_assoc($publishercheck);

            if(!$row2){
                $result1 = mysqli_query( $conn, "INSERT INTO Publishers (pubid, pname) VALUES ('".$publisherid."','".$publisher."')") or die("Could not execute query: " .mysqli_error($conn));
                $result2 = mysqli_query( $conn, "INSERT INTO Books (isbn, title, image, pubid, price, quantity_avail) VALUES ('".$isbn."','".$title."','".$image."','".$publisherid."','".$price."','".$inventory."')") or die("Could not execute query: " .mysqli_error($conn));
            }
            else{
                $pubid = $row2['pubid'];
                $result3 = mysqli_query( $conn, "INSERT INTO Books (isbn, title, image, pubid, price, quantity_avail) VALUES ('".$isbn."','".$title."','".$image."','".$pubid."','".$price."','".$inventory."')") or die("Could not execute query: " .mysqli_error($conn));
            }

// Check and insert author's information
            $authorcheck=mysqli_query( $conn, "SELECT * FROM Authors WHERE name = '".$author."'") or die("Could not execute query: " .mysqli_error($conn));
            $row3 = mysqli_fetch_assoc($authorcheck);

            if(!$row3){
                $result4 = mysqli_query( $conn, "INSERT INTO Authors (auid, name) VALUES ('".$auid."','".$author."')") or die("Could not execute query: " .mysqli_error($conn));
                $result5 = mysqli_query( $conn, "INSERT INTO Books_authors (isbn, auid) VALUES ('".$isbn."','".$auid."')") or die("Could not execute query: " .mysqli_error($conn));
            }else{
                $searchauid=mysqli_query( $conn, "SELECT * FROM Authors WHERE name = '".$author."'") or die("Could not execute query: " .mysqli_error($conn));
                $getauid = $searchauid['auid'];
                $result6 = mysqli_query( $conn, "INSERT INTO Books_authors (isbn, auid) VALUES ('".$isbn."','".$getauid."')") or die("Could not execute query: " .mysqli_error($conn));
            }

// Check and insert genre's information
            $genrecheck=mysqli_query( $conn, "SELECT * FROM Genres WHERE gname = '".$genre."'") or die("Could not execute query: " .mysqli_error($conn));
            $row4 = mysqli_fetch_assoc($genrecheck);

            if(!$row4){
                $result7 = mysqli_query( $conn, "INSERT INTO Genres (gid, gname) VALUES ('".$gid."','".$genre."')") or die("Could not execute query: " .mysqli_error($conn));
                $result8 = mysqli_query( $conn, "INSERT INTO Books_genres (isbn, gid) VALUES ('".$isbn."','".$gid."')") or die("Could not execute query: " .mysqli_error($conn));
            }else{
                $searchgid=mysqli_query( $conn, "SELECT * FROM Genres WHERE gname = '".$genre."'") or die("Could not execute query: " .mysqli_error($conn));
                $getgid = $searchgid['gid'];
                $result9 = mysqli_query( $conn, "INSERT INTO Books_genres (isbn, gid) VALUES ('".$isbn."','".$getgid."')") or die("Could not execute query: " .mysqli_error($conn));
            }

            echo "<script>alert('The book is added successfully!');</script>";
            header("refresh:2; url=../admin_book_manage.php");
            exit;
        } else{
            echo "<script>alert('ISBN already exists!');</script>";
            header("refresh:2; url=../create_book_page.php");
            exit;
        }

?>
