# -*- coding: utf-8 -*-
"""
Created on Mon Nov 18 01:07:25 2019

@author: tviel
"""

import os 
wd = os.path.dirname(os.path.realpath(__file__)) + "/"

wd = wd.replace("\\", "/")


file = open("data_upload.sql", "w+")

filenames = "addresses authors books_table books_authors cities employees favorites genres in_cart orders orders_books payments publishers ratings regions stores user user_addresses wishlists books_genres"
filenames = filenames.split()

file.write("USE final_dbm;")

for i in filenames:
    if i == "books_table":
        j = "books"
    else:
        j = i
        
    sql = """
LOAD DATA INFILE '"""+ wd + i +""".csv'
INTO TABLE """ + j + """
FIELDS TERMINATED BY ',' ENCLOSED BY '"'
LINES TERMINATED BY '\\n'
IGNORE 1 ROWS;
"""
    file.write(sql)
    

file.close()
