USE final_dbm;

TRUNCATE `addresses`;
TRUNCATE `authors`;
TRUNCATE `books`;
TRUNCATE `books_authors`;
TRUNCATE `books_genres`;
TRUNCATE `cities`;
TRUNCATE `employees`;
TRUNCATE `favorites`;
TRUNCATE `genres`;
TRUNCATE `in_cart`;
TRUNCATE `orders`;
TRUNCATE `orders_books`;
TRUNCATE `payments`;
TRUNCATE `publishers`;
TRUNCATE `ratings`;
TRUNCATE `regions`;
TRUNCATE `stores`;
TRUNCATE `user`;
TRUNCATE `user_addresses`;
TRUNCATE `wishlists`;

LOAD DATA INFILE 'C:/Users/tviel/Desktop/Python/2710_data_entry/addresses.csv'
INTO TABLE addresses
FIELDS TERMINATED BY ',' ENCLOSED BY '"'
LINES TERMINATED BY '\n'
IGNORE 1 ROWS;

LOAD DATA INFILE 'C:/Users/tviel/Desktop/Python/2710_data_entry/authors.csv'
INTO TABLE authors
FIELDS TERMINATED BY ',' ENCLOSED BY '"'
LINES TERMINATED BY '\n'
IGNORE 1 ROWS;

LOAD DATA INFILE 'C:/Users/tviel/Desktop/Python/2710_data_entry/employees.csv'
INTO TABLE employees
FIELDS TERMINATED BY ',' ENCLOSED BY '"'
LINES TERMINATED BY '\n'
IGNORE 1 ROWS;

LOAD DATA INFILE 'C:/Users/tviel/Desktop/Python/2710_data_entry/orders.csv'
INTO TABLE orders
FIELDS TERMINATED BY ',' ENCLOSED BY '"'
LINES TERMINATED BY '\n'
IGNORE 1 ROWS;

LOAD DATA INFILE 'C:/Users/tviel/Desktop/Python/2710_data_entry/payments.csv'
INTO TABLE payments
FIELDS TERMINATED BY ',' ENCLOSED BY '"'
LINES TERMINATED BY '\n'
IGNORE 1 ROWS;

LOAD DATA INFILE 'C:/Users/tviel/Desktop/Python/2710_data_entry/publishers.csv'
INTO TABLE publishers
FIELDS TERMINATED BY ',' ENCLOSED BY '"'
LINES TERMINATED BY '\n'
IGNORE 1 ROWS;

LOAD DATA INFILE 'C:/Users/tviel/Desktop/Python/2710_data_entry/stores.csv'
INTO TABLE stores
FIELDS TERMINATED BY ',' ENCLOSED BY '"'
LINES TERMINATED BY '\n'
IGNORE 1 ROWS;

LOAD DATA INFILE 'C:/Users/tviel/Desktop/Python/2710_data_entry/user.csv'
INTO TABLE user
FIELDS TERMINATED BY ',' ENCLOSED BY '"'
LINES TERMINATED BY '\n'
IGNORE 1 ROWS;

LOAD DATA INFILE 'C:/Users/tviel/Desktop/Python/2710_data_entry/favorites.csv'
INTO TABLE favorites
FIELDS TERMINATED BY ',' ENCLOSED BY '"'
LINES TERMINATED BY '\n'
IGNORE 1 ROWS;

LOAD DATA INFILE 'C:/Users/tviel/Desktop/Python/2710_data_entry/genres.csv'
INTO TABLE genres
FIELDS TERMINATED BY ',' ENCLOSED BY '"'
LINES TERMINATED BY '\n'
IGNORE 1 ROWS;

LOAD DATA INFILE 'C:/Users/tviel/Desktop/Python/2710_data_entry/in_cart.csv'
INTO TABLE in_cart
FIELDS TERMINATED BY ',' ENCLOSED BY '"'
LINES TERMINATED BY '\n'
IGNORE 1 ROWS;

LOAD DATA INFILE 'C:/Users/tviel/Desktop/Python/2710_data_entry/orders_books.csv'
INTO TABLE orders_books
FIELDS TERMINATED BY ',' ENCLOSED BY '"'
LINES TERMINATED BY '\n'
IGNORE 1 ROWS;

LOAD DATA INFILE 'C:/Users/tviel/Desktop/Python/2710_data_entry/ratings.csv'
INTO TABLE ratings
FIELDS TERMINATED BY ',' ENCLOSED BY '"'
LINES TERMINATED BY '\n'
IGNORE 1 ROWS;

LOAD DATA INFILE 'C:/Users/tviel/Desktop/Python/2710_data_entry/regions.csv'
INTO TABLE regions
FIELDS TERMINATED BY ',' ENCLOSED BY '"'
LINES TERMINATED BY '\n'
IGNORE 1 ROWS;

LOAD DATA INFILE 'C:/Users/tviel/Desktop/Python/2710_data_entry/user_addresses.csv'
INTO TABLE user_addresses
FIELDS TERMINATED BY ',' ENCLOSED BY '"'
LINES TERMINATED BY '\n'
IGNORE 1 ROWS;

LOAD DATA INFILE 'C:/Users/tviel/Desktop/Python/2710_data_entry/wishlists.csv'
INTO TABLE wishlists
FIELDS TERMINATED BY ',' ENCLOSED BY '"'
LINES TERMINATED BY '\n'
IGNORE 1 ROWS;

-- These are the things I've had problems with

LOAD DATA INFILE 'C:/Users/tviel/Desktop/Python/2710_data_entry/cities.csv'
INTO TABLE cities
FIELDS TERMINATED BY ',' ENCLOSED BY '"'
LINES TERMINATED BY '\n'
IGNORE 1 ROWS; 
-- this one is "0 index duplicated"

LOAD DATA INFILE 'C:/Users/tviel/Desktop/Python/2710_data_entry/books_authors.csv'
INTO TABLE books_authors
FIELDS TERMINATED BY ',' ENCLOSED BY '"'
LINES TERMINATED BY '\n'
IGNORE 1 ROWS;

LOAD DATA INFILE 'C:/Users/tviel/Desktop/Python/2710_data_entry/books_table.csv'
INTO TABLE books
FIELDS TERMINATED BY ',' ENCLOSED BY '"'
LINES TERMINATED BY '\n'
IGNORE 1 ROWS;


LOAD DATA INFILE 'C:/Users/tviel/Desktop/Python/2710_data_entry/books_genres.csv'
INTO TABLE books_genres
FIELDS TERMINATED BY ',' ENCLOSED BY '"'
LINES TERMINATED BY '\n'
IGNORE 1 ROWS;
