<?php
    // Include the functions page for common functions.
    include_once("includes/common_functions.php");

    // Create a connection to the database
    $conn = connection();

    $id = mt_rand(10000,99999);
    $email = $_POST["email"];
    $password = $_POST["password"];
    $firstname = $_POST["firstname"];
    $lastname = $_POST["lastname"];
    $phone = $_POST["phone"];

    if(strlen($email) > 50){
        echo "Email maximum length is 50 characters";
        header("refresh:3; url=../register.html");
        exit;
    } else if(strlen($password) > 25){
        echo "Password maximum length is 25 characters";
        header("refresh:3; url=../register.html");
        exit;
    } else if (strlen($firstname) > 45) {
        echo "First name  maximum length is 45 characters";
        header("refresh:3; url=../register.html");
        exit;
    } else if (strlen($lastname) > 45) {
        echo "Last name  maximum length is 45 characters";
        header("refresh:3; url=../register.html");
        exit;
    }else if (strlen($phone) > 12) {
        echo "Phone maximun length is 12";
        header("refresh:3; url=../register.html");
        exit;
    }

        if ($conn->connect_error)
        {
            die("Connection failed: " . $conn->connect_error);
        }

        $ret=mysqli_query( $conn, "SELECT email FROM Users WHERE email = '".$email."'") or die("Could not execute query: " .mysqli_error($conn));
        $row = mysqli_fetch_assoc($ret);
        if(!$row){
            $result = $conn->query("INSERT INTO Users (uid, fName, lName, email, PASSWORD, phone) VALUES ('".$id."','".$firstname."','".$lastname."','".$email."','".$password."','".$phone."')");
            echo "<script>alert('Successfully Register!');</script>";
            header("refresh:2;index.html");
            exit;
        } else{
            echo "<script>alert('Email Address already exists!');</script>";
            header("refresh:2; url=../register_home.html");
            exit;
        }

?>
