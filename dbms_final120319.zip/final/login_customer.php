<?php
    // Include the functions page for common functions.
    include_once("includes/common_functions.php");

    // Create a connection to the database
    $conn = connection();
    session_start();

    // Check connection
    if ($conn->connect_error)
    {
        die("Connection failed: " . $conn->connect_error);
    }
    if( isset($_POST['email']) and isset($_POST['password']) ) {

        $user=$_POST['email'];
        $pass=$_POST['password'];

        $ret=mysqli_query( $conn, "SELECT * FROM Users WHERE email='$user' AND PASSWORD='$pass' ") or die("Could not execute query: " .mysqli_error($conn));
        $row = mysqli_fetch_assoc($ret);
        if(!$row) {
          header("refresh: 2; url='index.html'");
          exit;
        }
        else {
          $userid = $row['uid'];
          $_SESSION['email'] = $user;
          $_SESSION['password'] = $pass;
          $_SESSION['userid'] = $userid;
          header("refresh: 5; url='home.php'");
          exit;
        }
      }

  ?>
