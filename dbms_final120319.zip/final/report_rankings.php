<?php
    // Include the functions page for common functions.
    include_once("includes/common_functions.php");

    // Create a connection to the database
    $conn = connection();
    session_start();
    $fName = $_SESSION['fname'];
    $lName = $_SESSION['lname'];
    $employeeid = $_SESSION['eid'];
    $email = $_SESSION['email'];
    $password = $_SESSION['password'];

    $result=mysqli_query( $conn, "SELECT * FROM Employees, Users WHERE Email = '".$email."' AND Password = '".$password."' AND Employees.uid = Users.uid") or die("Could not execute query: " .mysqli_error($conn));
    $row = mysqli_fetch_assoc($result);

  	if($row == ""){
      echo "Unauthorized Access!";
  		header("refresh:3; url=index.html");
  		exit;
  	}

 ?>

<!DOCTYPE html>
<html lang="en">
<head>
<title>Admin | Sales Report</title>
<meta charset="utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1"/>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>

<style>
.active{
  color: black;
  font-weight: bold;
}

.table{
  margin: auto;
  width: 60%;
  table-layout: fixed;
}

#table1{
  margin: auto;
  width: 60%;
  table-layout: fixed;
  text-align: center;
}

#table1 th{
  text-align: center;
}


.onecol{
  width:20%;
}

.twocol{
  width:60%;
}

.bestseries{
  margin-top: 30px;
}

h1{
  text-align: center;
  margin-top: 30px;
}


button{

  border: solid 1px grey;
}
</style>
</head>
<body>
  <img class="logo" src="images/logo.PNG"/>
  <nav class="navbar navbar-default">
    <!-- the options changes depending on what page the user is on-->
    <div class="collapse navbar-collapse" id="myNavbar">
      <ul class="nav navbar-nav navbar-right">
        <li id="User"><a href="admin_user_manage.php">Users</a></li>
        <li id="Book"><a href="admin_book_manage.php">Books</a></li>
        <li id="Transaction"><a href="admin_transaction_manage.php">Transactions</a></li>
        <li id="Sales_Report"><a class="active" href="admin_sales_report.php">Sales Report&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</a></li>
        <li><a style="color: red;"><?php echo $fName." ".$lName." (eid:".$employeeid.")";?></a></li>
        <li id="Logout"><a href="logout.php">Logout</a></li>
      </ul>
    </div>
  </nav>

 <h1>Top 10 Books</h1>
 <div class="bestseries">
<?php
  $result2 = mysqli_query( $conn, "SELECT Books.isbn, Books.title, sum(units)
                                    FROM Books, Orders_books
                                    WHERE Books.isbn = Orders_books.isbn
                                    GROUP BY Books.isbn
                                    ORDER BY SUM(units) DESC
                                    LIMIT 10") or die("Could not execute query: " .mysqli_error($conn));
  if($result2){
?>
        <table class="table">
          <thead>
            <tr>
              <th class = "onecol">ISBN</th>
              <th class = "twocol">Book Title</th>
              <th class = "onecol">Total Sale</th>
            </tr>
          </thead>
<?php
  }
  echo "<tbody>";
  while ($row2 = mysqli_fetch_row($result2)){
?>
          <tbody>
            <tr>
              <td><?php echo $row2[0]?></td>
              <td><?php echo $row2[1]?></td>
              <td><?php echo $row2[2]?></td>
            </tr>
          </tbody>
<?php
  }
  echo "</tbody></table>";
?>
      </div>


      <h1>Top 10 Genres</h1>
      <div class="bestseries">
      <?php
       $result3 = mysqli_query( $conn, "SELECT Genres.gname, SUM(Orders_books.units)
                                          FROM Orders_books, Books_genres, Genres
                                          WHERE Books_genres.isbn = Orders_books.isbn
                                          AND Books_genres.gid = Genres.gid
                                          GROUP BY Orders_books.isbn, Genres.gname
                                          ORDER BY SUM(units) DESC
                                          LIMIT 10") or die("Could not execute query: " .mysqli_error($conn));
       if($result3){
      ?>
             <table class="table" id = "table1">
               <thead>
                 <tr>
                   <th>Genre</th>
                   <th>Total Sale</th>
                 </tr>
               </thead>
      <?php
       }
       echo "<tbody>";
       while ($row2 = mysqli_fetch_row($result3)){
      ?>
               <tbody>
                 <tr>
                   <td><?php echo $row2[0]?></td>
                   <td><?php echo $row2[1]?></td>
                 </tr>
               </tbody>
      <?php
       }
       echo "</tbody></table>";
      ?>
           </div>

</body>

</html>
