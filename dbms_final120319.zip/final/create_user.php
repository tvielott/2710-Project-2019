<?php
    // Include the functions page for common functions.
    include_once("includes/common_functions.php");

    // Create a connection to the database
    $conn = connection();
    
    session_start();
    $fName = $_SESSION['fname'];
    $lName = $_SESSION['lname'];
    $employeeid = $_SESSION['eid'];
    $email = $_SESSION['email'];
    $password = $_SESSION['password'];


    $id = mt_rand(10000,99999);
    $cid = mt_rand(1000,9999);
    $aid = mt_rand(1000,9999);
    $email = $_POST["email"];
    $password = $_POST["password"];
    $firstname = $_POST["firstname"];
    $lastname = $_POST["lastname"];
    $phone = $_POST["phone"];
    $street = $_POST["street"];
    $city = $_POST["city"];
    $state = $_POST["state"];
    $zip = $_POST["zip"];

    if(strlen($email) > 50){
        echo "Email maximum length is 50 characters";
        header("refresh:3; url=../create_user_page.php");
        exit;
    } else if(strlen($password) > 25){
        echo "Password maximum length is 25 characters";
        header("refresh:3; url=../create_user_page.php");
        exit;
    } else if (strlen($firstname) > 45) {
        echo "First name  maximum length is 45 characters";
        header("refresh:3; url=../create_user_page.php");
        exit;
    } else if (strlen($lastname) > 45) {
        echo "Last name  maximum length is 45 characters";
        header("refresh:3; url=../create_user_page.php");
        exit;
    }else if (strlen($phone) > 12) {
        echo "Phone maximun length is 12";
        header("refresh:3; url=../create_user_page.php");
        exit;
    }else if (strlen($street) > 50) {
        echo "Street maximun length is 50";
        header("refresh:3; url=../create_user_page.php");
        exit;
    }else if (strlen($city) > 50) {
        echo "City maximun length is 50";
        header("refresh:3; url=../create_user_page.php");
        exit;
    }else if (strlen($state) > 25) {
        echo "State maximun length is 25";
        header("refresh:3; url=../create_user_page.php");
        exit;
    }else if (strlen($zip) > 15) {
        echo "Zip maximun length is 15";
        header("refresh:3; url=../create_user_page.php");
        exit;
    }


        if ($conn->connect_error)
        {
            die("Connection failed: " . $conn->connect_error);
        }

        $ret=mysqli_query( $conn, "SELECT email FROM Users WHERE email = '".$email."'") or die("Could not execute query: " .mysqli_error($conn));
        $row1 = mysqli_fetch_assoc($ret);

        if(!$row1){
            $result = mysqli_query( $conn, "INSERT INTO Users (uid, fName, lName, email, PASSWORD, phone) VALUES ('".$id."','".$firstname."','".$lastname."','".$email."','".$password."','".$phone."')")or die("Could not execute query: " .mysqli_error($conn));

            $citycheck=mysqli_query( $conn, "SELECT * FROM Cities WHERE cname = '".$city."' AND state = '".$state."'") or die("Could not execute query: " .mysqli_error($conn));
            $row2 = mysqli_fetch_assoc($citycheck);

            if(!$row2){
                $result = mysqli_query( $conn, "INSERT INTO Cities (cid, cname, state) VALUES ('".$cid."','".$city."','".$state."')") or die("Could not execute query: " .mysqli_error($conn));
                $result = mysqli_query( $conn, "INSERT INTO Addresses (aid, uid, street, cid, zip) VALUES ('".$aid."','".$id."','".$street."','".$cid."','".$zip."')") or die("Could not execute query: " .mysqli_error($conn));
            }
            $cityid = $row2['cid'];
            $result = mysqli_query( $conn, "INSERT INTO Addresses (aid, uid, street, cid, zip) VALUES ('".$aid."','".$id."','".$street."','".$cityid."','".$zip."')") or die("Could not execute query: " .mysqli_error($conn));

            echo "<script>alert('The user is created successfully!');</script>";
            header("refresh:2; url=../admin_user_manage.php");
            exit;
        } else{
            echo "<script>alert('Email Address already exists!');</script>";
            header("refresh:2; url=../create_user_page.php");
            exit;
        }

?>
