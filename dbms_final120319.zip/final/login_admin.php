<?php
    // Include the functions page for common functions.
    include_once("includes/common_functions.php");

    // Create a connection to the database
    $conn = connection();
    session_start();

    $email = $_POST["email"];
    $password = $_POST["password"];

    // Check connection
    if ($conn->connect_error)
    {
        die("Connection failed: " . $conn->connect_error);
    }
    if ($email && $password){
        $result=mysqli_query( $conn, "SELECT * FROM Employees, Users WHERE Email = '".$email."' AND Password = '".$password."' AND Employees.uid = Users.uid") or die("Could not execute query: " .mysqli_error($conn));
        $row = mysqli_fetch_assoc($result);

        $fName = $row['fName'];
        $lName = $row['lName'];
        $employeeid = $row['eid'];

        if($row){
            $employeeid = $row['eid'];
            $_SESSION['fname'] = $fName;
            $_SESSION['lname'] = $lName;
            $_SESSION['email'] = $email;
            $_SESSION['password'] = $password;
            $_SESSION['eid'] = $employeeid;
            echo "Successfully Login!";
            header("refresh:2; url=./admin_user_manage.php");
            exit;
        }else{
            echo "Your email or password wasn’t recognized. Please try again.";
            header("refresh:2; url=../login_admin.html");
            exit;
        }
    } else{
        echo "Incomplete From. Please try again.";
        header("refresh:2; url=../login_admin.html");
        exit;
    }



?>
