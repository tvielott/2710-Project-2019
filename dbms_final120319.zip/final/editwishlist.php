<?php
  // Include the functions page for common functions.
  include_once("includes/common_functions.php");

  // Create a connection to the database
  $connect = connection();

  // If the user is logged in then assign the username variable from session info.
  session_start();
	$username = $_SESSION['user'];

	$result=mysqli_query( $connect, "SELECT uid FROM Users WHERE Email = '".$username."'") or die("Could not execute query: " .mysqli_error($connect));

	 while($row = mysqli_fetch_assoc($result)) {
			$userID = $row['uid'];
		}

	 $userID = mysqli_real_escape_string($connect, $userID);

  // Free the results
  mysqli_free_result($result);

  //If remove button clicked then remove from wishlists table
      $isbn = $_GET['isbn'];
      $isbn = mysqli_real_escape_string($connect, $isbn);

      $delquery = "DELETE from wishlists";
      $delquery.= " WHERE isbn = '{$isbn}' AND uid = '{$userID}';";

      // Perform the database query
      $delresult = mysqli_query($connect, $delquery);

      // If the query failed, then kill the database and output the failure.
      if (!$delresult) {
        printf("DB Failed: %s\n", mysqli_error($connect));
        die("Database query failed.");
        echo "Remove favorite query error";
      } else {
          header('Location: books.php');
      }

?>
