<?php
  // Include the functions page for common functions.
  include_once("includes/common_functions.php");

  // Create a connection to the database
  $connect = connection();

  // If the user is logged in then assign the username variable from session info.
  session_start();
  $username = $_SESSION['user'];

  $result=mysqli_query( $connect, "SELECT uid FROM Users WHERE Email = '".$username."'") or die("Could not execute query: " .mysqli_error($connect));

   while($row = mysqli_fetch_assoc($result)) {
      $userID = $row['uid'];
    }

   $userID = mysqli_real_escape_string($connect, $userID);

?>
<!DOCTYPE html>
<html lang="en">
<head>
<title>Book Leaf | Home</title>
<meta charset="utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1"/>
<link rel="stylesheet" type="text/css" href="style/styles.css">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
</head>
<body>
  <img class="logo" src="images/logo.PNG"/>
  <nav class="navbar navbar-default">
  <div class="container">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
      </button>
    </div>
    <div class="collapse navbar-collapse" id="myNavbar">
      <ul class="nav navbar-nav navbar-right">
        <li id="books"><a href="books.php">Search Books</a></li>
        <li id="favorites"><a href="favorites.php">Favorites</a></li>
        <li id="wishlist"><a href="wishlist.php">Wishlist</a></li>
        <li id="cart"><a href="cart.php">Cart</a></li>
        <li id="orders"><a href="orders.php">Orders</a></li>
        <li id="Logout"><a href="logout.php">Logout</a></li>
      </ul>
    </div>
  </div>
</nav>
  <div class="container-fluid bg-3 text-center">
  <h1>Welcome <?php echo $username;?></h1>
  <div class="row">
    <div class="col-sm-4">

    </div>
    <div class="col-sm-4">

      </div>
    </div>
    <div class="col-sm-4">


    </div>
  </div>
<script>

</script>
</body>
<?php
  // Close the db connection.
    mysqli_close($connect);

?>
</html>
