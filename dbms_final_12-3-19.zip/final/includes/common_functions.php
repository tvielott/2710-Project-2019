<?php
  //function establishes connection to the bookleaf Database
  function connection(){
    //set the variables
    $host = "LAPTOP-IHSVJ22T";
    $user = "sal137";
    $password = "test";
    $dbname = "book_leaf";
    $db_port = '3306';

    $connect = mysqli_connect($host, $user, $password, $dbname,$db_port);
    // Disconnect if there is an error.
    if(mysqli_connect_errno()){
      die("Database connection failed: ".
        mysqli_connect_error() .
        " (" . mysqli_connect_errno(). ")"
        );
      } else {
      return $connect;
      }
    }

  // This function checks if the user is logged in.
  // If the user is logged in then have a link at top that allows the user to log out
  // If the user is viewing as a guest then have a link that allows the user to log in
  // Both of these links sends the user back to the login page.
  function login() {
    session_start();
    if (!isset($_SESSION['login_user'])) {
      ?>

      <a href="login.php">Login</a>

    <?php
    } else {
    ?>
      <a href="login.php?loggedout=1">Logout</a>
    <?php
    }
  }

  // This function checks if the value is present by making sure it isn't empty.
  // Returns true if present.
  function is_present($value){
    return $value !== "";
  }


?>
