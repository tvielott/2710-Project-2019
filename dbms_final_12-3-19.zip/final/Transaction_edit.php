<?php
    // Include the functions page for common functions.
    include_once("includes/common_functions.php");

    // Create a connection to the database
    $conn = connection();
    session_start();
    $fName = $_SESSION['fname'];
    $lName = $_SESSION['lname'];
    $employeeid = $_SESSION['eid'];
    $email = $_SESSION['email'];
    $password = $_SESSION['password'];

    $result=mysqli_query( $conn, "SELECT * FROM Employees, Users WHERE Email = '".$email."' AND Password = '".$password."' AND Employees.uid = Users.uid") or die("Could not execute query: " .mysqli_error($conn));
    $row = mysqli_fetch_assoc($result);

  	if($row == ""){
      echo "Unauthorized Access!";
  		header("refresh:3; url=index.html");
  		exit;
  	}

    $oid = $_GET["oid"];
    $result=mysqli_query( $conn, "SELECT * FROM Orders WHERE oid = '".$oid."'") or die("Could not execute query: " .mysqli_error($conn));
    $row = mysqli_fetch_assoc($result);
 ?>

<!DOCTYPE html>
<html lang="en">
<head>
<title>Admin | Transaction Management</title>
<meta charset="utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1"/>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>

<style>
.active{
  color: black;
  font-weight: bold;
}

.form{
  width: 70%;
  margin: 0 auto;
}

.table{
  width: 60%;
}

button{

  border: solid 1px grey;
}
</style>
</head>
<body>
  <img class="logo" src="images/logo.PNG"/>
  <nav class="navbar navbar-default">
    <!-- the options changes depending on what page the user is on-->
    <div class="collapse navbar-collapse" id="myNavbar">
      <ul class="nav navbar-nav navbar-right">
        <li id="User"><a href="admin_user_manage.php">Users</a></li>
        <li id="Book"><a href="admin_book_manage.php">Books</a></li>
        <li id="Transaction"><a class="active" href="admin_transaction_manage.php">Transactions</a></li>
        <li id="Sales_Report"><a href="admin_sales_report.php">Sales Report&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</a></li>
        <li><a style="color: red;"><?php echo $fName." ".$lName." (eid:".$employeeid.")";?></a></li>
        <li id="Logout"><a href="logout.php">Logout</a></li>
      </ul>
    </div>
  </nav>

  <form action="./update_transaction.php?oid=<?php echo $row['oid']?>" id="transaction_form" class="form" method="post">

      <div style="font-size:25px;margin-bottom:20px;"> Order Number<bold>: <?php echo $row['oid']?> </div>
      <div style="font-size:25px;margin-bottom:20px;"> Order Date<bold>: <?php echo $row['order_date']?> </div>

      <div class="form-group row">
          <label for="shippeddate" class="col-sm-2 col-form-label">Shipped date:</label>
          <input type="date" class="form-control col-sm-10" id="shippeddate" name="shippeddate" value="<?php echo $row['shipped_date']?>" required>
      </div>
      <div class="form-group row">
          <label for="status" class="col-sm-2 col-form-label">Order status:</label>
          <select name="status">
          <option value="0" <?php if($row['completed']==0) echo 'selected = "selected"';?> >Incompleted</option>
          <option value="1" <?php if($row['completed']==1) echo 'selected = "selected"';?> >Completed</option>
          </select>
      </div>

<!--Order_Item's information-->
      <div class="form-group row">
<?php
  $result2 = mysqli_query( $conn, "SELECT Orders_books.isbn, Books.title, Orders_books.units, Books.price, Orders_books.price_at_sale FROM Orders, Orders_books, Books WHERE Orders.oid = '".$oid."' AND Orders.oid = Orders_books.oid AND Orders_books.isbn = Books.isbn") or die("Could not execute query: " .mysqli_error($conn));
  if($result2){
?>
        <label for="iteminformation" class="col-sm-2 col-form-label">Item's information:</label>
        <table class="table">
          <thead>
            <tr>
              <th>ISBN</th>
              <th>Title</th>
              <th>Unit</th>
              <th>Price</th>
              <th>Price at sale</th>
            </tr>
          </thead>
<?php
  }
  echo "<tbody>";
  while ($row2 = mysqli_fetch_row($result2)){
?>
          <tbody>
            <tr>
              <th><?php echo $row2[0]?></th>
              <th><?php echo $row2[1]?></th>
              <th><?php echo $row2[2]?></th>
              <th><?php echo $row2[3]?></th>
              <th><?php echo $row2[4]?></th>
            </tr>
          </tbody>
<?php
  }
  echo "</tbody></table>";
?>
      </div>

<!--Order_Saler's information-->
      <div class="form-group row">
      <?php
      $result3 = mysqli_query( $conn, "SELECT Orders.eid, Users.fName, Users.lName, Stores.sname, Regions.rname FROM Orders, Users, Employees, Stores, Regions WHERE Orders.oid = '".$oid."' AND Orders.eid = Employees.eid AND Employees.uid = Users.uid AND Employees.sid = Stores.sid AND Stores.rid = Regions.rid") or die("Could not execute query: " .mysqli_error($conn));
      if($result3){
      ?>
        <label for="salerinformation" class="col-sm-2 col-form-label">Saler's information:</label>
        <table class="table">
          <thead>
            <tr>
              <th>EID</th>
              <th>First name</th>
              <th>Last name</th>
              <th>Store</th>
              <th>Region</th>
            </tr>
          </thead>
      <?php
      }
      echo "<tbody>";
      while ($row3 = mysqli_fetch_row($result3)){
      ?>
          <tbody>
            <tr>
              <th><?php echo $row3[0]?></th>
              <th><?php echo $row3[1]?></th>
              <th><?php echo $row3[2]?></th>
              <th><?php echo $row3[3]?></th>
              <th><?php echo $row3[4]?></th>
            </tr>
          </tbody>
      <?php
      }
      echo "</tbody></table>";
      ?>
      </div>

<!--Order_Customer's basic information-->
      <div class="form-group row">
      <?php
      $result4 = mysqli_query( $conn, "SELECT Users.uid, Users.fName, Users.lName, Users.email, Users.phone FROM Orders, Users WHERE Orders.oid = '".$oid."' AND Orders.uid = Users.uid") or die("Could not execute query: " .mysqli_error($conn));
      if($result4){
      ?>
        <label for="customerinformation" class="col-sm-2 col-form-label">Customer's information:</label>
        <table class="table">
          <thead>
            <tr>
              <th>Customer's UID</th>
              <th>First name</th>
              <th>Last name</th>
              <th>Email</th>
              <th>Phone</th>
            </tr>
          </thead>
      <?php
      }
      echo "<tbody>";
      while ($row4 = mysqli_fetch_row($result4)){
      ?>
          <tbody>
            <tr>
              <th><?php echo $row4[0]?></th>
              <th><?php echo $row4[1]?></th>
              <th><?php echo $row4[2]?></th>
              <th><?php echo $row4[3]?></th>
              <th><?php echo $row4[4]?></th>
            </tr>
          </tbody>
      <?php
      }
      echo "</tbody></table>";
      ?>
      </div>

<!--Order_Shipping address information-->
      <div class="form-group row">
      <?php
      $result5 = mysqli_query( $conn, "SELECT Addresses.street, Cities.cname, Cities.state, Addresses.zip FROM Orders, Addresses, Cities WHERE Orders.oid = '".$oid."' AND Orders.aid = Addresses.aid AND Addresses.cid = Cities.cid") or die("Could not execute query: " .mysqli_error($conn));
      if($result5){
      ?>
        <label for="shippingaddressinformation" class="col-sm-2 col-form-label">Shipping address:</label>
        <table class="table">
          <thead>
            <tr>
              <th>Street</th>
              <th>City</th>
              <th>State</th>
              <th>Zip code</th>
            </tr>
          </thead>
      <?php
      }
      echo "<tbody>";
      while ($row5 = mysqli_fetch_row($result5)){
      ?>
          <tbody>
            <tr>
              <th><?php echo $row5[0]?></th>
              <th><?php echo $row5[1]?></th>
              <th><?php echo $row5[2]?></th>
              <th><?php echo $row5[3]?></th>
            </tr>
          </tbody>
      <?php
      }
      echo "</tbody></table>";
      ?>
      </div>

      <div class="form-group">
          <button type="submit" class="btn btn-secondary">Update</button>
          <a href="./delete_transaction.php?oid=<?php echo $row['oid']?>" class="btn btn-secondary">Delete</button>
      </div>
  </form>

</body>

</html>
