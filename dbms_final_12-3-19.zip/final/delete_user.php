<?php
    // Include the functions page for common functions.
    include_once("includes/common_functions.php");

    // Create a connection to the database
    $conn = connection();
    session_start();
    $fName = $_SESSION['fname'];
    $lName = $_SESSION['lname'];
    $employeeid = $_SESSION['eid'];
    $email = $_SESSION['email'];
    $password = $_SESSION['password'];
    
    $result=mysqli_query( $conn, "SELECT * FROM Employees, Users WHERE Email = '".$email."' AND Password = '".$password."' AND Employees.uid = Users.uid") or die("Could not execute query: " .mysqli_error($conn));
    $row = mysqli_fetch_assoc($result);

  	if($row == ""){
      echo "Unauthorized Access!";
  		header("refresh:3; url=index.html");
  		exit;
  	}

    $uid = $_GET["uid"];
    $result=mysqli_query( $conn, "DELETE FROM Users WHERE uid = '".$uid."'") or die("Could not execute query: " .mysqli_error($conn));

    if($result){
      echo "User has been deleted!";
      header("refresh:2; url=./admin_user_manage.php");
      exit;
    }
 ?>
