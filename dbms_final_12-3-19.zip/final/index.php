<?php
  // Include the functions page for common functions.
  include_once("includes/common_functions.php");

  // Create a connection to the database
  $connect = connection();

  // Check if the loggedout param is passed - this happens when the user clicks logout button.
	if (isset($_GET['loggedout'])) {

		// If loggedout param is passed then unset the session with an empty array then destorying the session.
		session_start();
		$_SESSION = array();
		session_destroy();
	}

  //If the user submitted the registration form, do the following
  if($_POST){
    // Get the posted values and assigned them to variables.
    $username = trim($_POST['username']);
    $password = trim($_POST['password']);
    $email = trim($_POST['email']);
    $fname = trim($_POST['fname']);
    $lname = trim($_POST['lname']);

    //echo "hi ". $username;

    $errors = 0;

    if(!preg_match("/^[a-zA-Z\d]+$/", $username)) {
      $error_messages = "<div class=\"errors\">Username can only include numbers and letters.<br><br></div>";
      $errors.=1;
    } else {

      // If there are no errors check whether that username exists in the db.
      $result = mysqli_query($connect, "SELECT * FROM user WHERE uid = '{$username}'");

      $count = mysqli_num_rows($result);

      if (!$result) {

      printf("DB Failed: %s\n", mysqli_error($connect));
      die("Database query failed.");

      }
      else {
        if ($count == 1) {
          echo "<div class=\"errors\">Username already taken.<br><br></div>";
          $errors.=1;
        }
      }
    } //end of outer else
    if($errors ==0){

      //If there are no  errors, enter the user into the Database
      $query ="INSERT INTO `user`";
      $query.=" (uid, fName, lName, email, password, phone, pid)";
      $query.=" VALUES ('{$username}', '{$fname}', '{$lname}', '{$email}', '{$password}', '{$phone}', '');";

      // Perform the database query
      $result = mysqli_query($connect, $query);

      // If the query failed, then kill the database and output the failure.
      if (!$result) {
        printf("DB Failed: %s\n", mysqli_error($connect));
        die("Database query failed.");

      } else {
        // Start session
        session_start();
        $_SESSION['login_user'] = $username;
        echo $_SESSION['login_user'];
        header("Location: home.php");
      }
  }

} //end of if($_POST)



?>
<!DOCTYPE html>
<html lang="en">
<head>
<title>Book Leaf Home</title>
<meta charset="utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1"/>
<link rel="stylesheet" type="text/css" href="style/styles.css">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
</head>
<body>
  <img class="logo" src="images/logo.PNG"/>
  <nav class="navbar navbar-default">
  <div class="container">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
      </button>
    </div>
    <div class="collapse navbar-collapse" id="myNavbar">
      <ul class="nav navbar-nav navbar-right">
        <li id="books"><a href="books.php">Books</a></li>
        <li id="login"><a href="login.php">Log In</a></li>
      </ul>
    </div>
  </div>
</nav>
  <div class="container-fluid bg-3 text-center">
  <h1>Register to Book Leaf</h1>
  <div class="row">
    <div class="col-sm-4">

    </div>
    <div class="col-sm-4">
        <form name="register" method = "POST" action="index.php">
          <div class="form-group">
            <label for='username'>Username</label>
            <input type="text" class="form-control" name="username" required>
            <br>
            <label for="password">Password</label>
            <input type="password" class="form-control" name="password" required><br>
            <label for='fname'>First Name</label>
            <input type="text" class="form-control" name="fname" required>
            <br>
            <label for='lname'>Last Name</label>
            <input type="text" class="form-control" name="lname" required><br>
            <label for="email">Email</label>
            <input type="email"class="form-control" name="email" required><br>
            <button type="submit" class="btn btn-primary">Register</button>
          </div>
        </form>
        <br>
        <a href="login.php">Login instead?</a>
      </div>
    </div>
    <div class="col-sm-4">


    </div>
  </div>
<script>

</script>
</body>
<?php
  // Close the db connection.
    mysqli_close($connect);

?>
</html>
