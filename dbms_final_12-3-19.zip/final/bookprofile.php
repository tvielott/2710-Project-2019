<?php
  // Include the functions page for common functions.
  include_once("includes/common_functions.php");

	// Create a connection to the database
	$connect = connection();

  session_start();
  $username = $_SESSION['user'];


  $result=mysqli_query( $connect, "SELECT uid FROM Users WHERE Email = '".$username."'") or die("Could not execute query: " .mysqli_error($connect));

   while($row = mysqli_fetch_assoc($result)) {
      $uid = $row['uid'];
    }

  //grab the isbn number sent over
	if ($_GET) {
		$isbn = $_GET['isbn'];
    //echo $isbn;
	}

  $query = "SELECT * FROM books WHERE isbn = '{$isbn}';";
  $result = mysqli_query($connect, $query);

  // Check that the query did not fail.
  if (!$result) {
    printf("DB Failed: %s\n", mysqli_error($connect));
    die("Database query failed.");

  // If it didn't fail, then retrieve the rows with mysqli_fetch_assoc and get the data using the column names.
  } else {
      $count = mysqli_num_rows($result);

       while($row = mysqli_fetch_assoc($result)) {
          $title = $row['title'];
          $image = $row['image'];
          $price = $row['price'];
          $quantity = $row['quantity_avail'];
    }
  }
  // Free the results
  mysqli_free_result($result);

  //Get the publisher
  $pubquery = "SELECT DISTINCT p.pname FROM books b LEFT JOIN publishers p ON b.pubid = p.pubid WHERE b.isbn = '{$isbn}';";
  $result = mysqli_query($connect, $pubquery);

  // Check that the query did not fail.
  if (!$result) {
    printf("DB Failed: %s\n", mysqli_error($connect));
    die("Database query failed.");

  // If it didn't fail, then retrieve the rows with mysqli_fetch_assoc and get the data using the column names.
  } else {
    while($row = mysqli_fetch_assoc($result)) {
       $publisher = $row['pname'];
       //echo $publisher;
   }
  }
  mysqli_free_result($result);

  //Get the author
  $authquery = "SELECT DISTINCT a.name FROM books b LEFT JOIN books_authors ba ON ba.isbn = b.isbn";
  $authquery.= " LEFT JOIN authors a ON a.auid = ba.auid WHERE b.isbn = '{$isbn}';";
  $result = mysqli_query($connect, $authquery);

  // Check that the query did not fail.
  if (!$result) {
    printf("DB Failed: %s\n", mysqli_error($connect));
    die("Database query failed.");

  // If it didn't fail, then retrieve the rows with mysqli_fetch_assoc and get the data using the column names.
  } else {
    while($row = mysqli_fetch_assoc($result)) {
       $author = $row['name'];
       //echo $author;
   }
  }
  mysqli_free_result($result);

  $countrate = "SELECT COUNT(rating) as count FROM ratings WHERE isbn = '{$isbn}';";
  $result = mysqli_query($connect, $countrate);

  // Check that the query did not fail.
  if (!$result) {
    printf("DB Failed: %s\n", mysqli_error($connect));
    die("Database query failed.");

  // If it didn't fail, then retrieve the rows with mysqli_fetch_assoc and get the data using the column names.
  } else {
    while($row = mysqli_fetch_assoc($result)) {
       $count = $row['count'];
   }
 }
 mysqli_free_result($result);

  // Get the average rating for the book
  $ratingq = "SELECT AVG(rating) as average FROM ratings WHERE isbn = '{$isbn}';";
  $result = mysqli_query($connect, $ratingq);

  // Check that the query did not fail.
  if (!$result) {
    printf("DB Failed: %s\n", mysqli_error($connect));
    die("Database query failed.");

  // If it didn't fail, then retrieve the rows with mysqli_fetch_assoc and get the data using the column names.
} else{
  while($row = mysqli_fetch_assoc($result)) {
     $rating = round($row['average'],2);

   }
 }
  mysqli_free_result($result);

?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <title>Book Leaf | Book Profile</title>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1"/>
    <link rel="stylesheet" type="text/css" href="style/styles.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  </head>
  <body>
    <img class="logo" src="images/logo.PNG"/>
    <nav class="navbar navbar-default">
      <div class="container">
        <div class="navbar-header">
          <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
        </div>
        <div class="collapse navbar-collapse" id="myNavbar">
          <ul class="nav navbar-nav navbar-right">
            <li id="books"><a href="books.php">Search Books</a></li>
            <li id="favorites"><a href="favorites.php">Favorites</a></li>
            <li id="wishlist"><a href="wishlist.php">Wishlist</a></li>
             <li id="cart"><a href="cart.php">Cart</a></li>
            <li id="orders"><a href="orders.php">Orders</a></li>
            <li id="Logout"><a href="logout.php">Logout</a></li>
          </ul>
        </div>
      </div>
    </nav>
    <div class="container-fluid bg-3 text-center">
    <h3><?php echo $title;?></h3>
    <div class="row">
      <div class="col-sm-4" style="margin-top:15px">
          <img style="height:40%; width:40%;" src="<?php echo $image; ?>">
      </div>
      <div class="col-sm-4" style="text-align:left; margin-top:15px">
        <em>Author:</em> <?php echo $author; ?><br>
        <em>Publisher:</em> <?php echo $publisher; ?><br>
        <em>Price:</em> <?php echo $price; ?><br>
        <em>Average Rating:</em> <?php echo $rating; ?><br>
        <em>(Number of Ratings):</em> <?php echo $count; ?><br>

        <?php
        if($quantity<1){
          echo "Quantity: Out Of Stock<br>";
        }
        else{
          echo '<em>(Quantity Aviliable):</em>'.$quantity.'<br>';
        }


         ?>

      </div>
      <div class="col-sm-4" style="margin-top:15px; text-align:left">
        <!-- This is where the user can add the book to cart-->
        <form action="cart.php" <?php if($quantity<1){ echo "style='display:none;'";} ?>>
          Quantity: <input type="number" name="qty" min="1" oninput="check(this)" value="1" style="width: 50px;padding:0;"><br><br>

          <input type="submit" value="Add To Cart"  style="width:111px;"/>
          <input type="hidden" name="action" value="insert"/>
          <input type="hidden" name="isbn" value="<?php echo $isbn;?>"/>
        </form><br>
        <!-- Add the book to favorites or wishlist-->
        <form action="favorites.php">
          <input type="submit" value="Favorite" />
          <input type="hidden" name="isbn" value="<?php echo $isbn;?>"/>
        </form><br>
        <form action="wishlist.php">
          <input type="submit" value="Wishlist" />
          <input type="hidden" name="isbn" value="<?php echo $isbn;?>"/>
        </form>
      </div>
      </div>
      <div class="row">
      <div class="col-sm-4" style="margin-top:15px">
      </div>
      <div class="col-sm-4" style="margin:15px">
        <h4>Leave a rating</h4>
        <form id="ratingform" method="post" action="createRating.php">
          <div class="form-group">
            <label for="review">Review: </label>
            <textarea class="form-control" id="review" name="review" rows="2"></textarea>
          </div>
           <div class="form-group">
             <label for="rating">Rating: </label>
             <select class="form-control" id="rating" name="rating">
               <option value="1">1</option>
               <option value="2">2</option>
               <option value="3">3</option>
               <option value="4">4</option>
               <option value="5">5</option>
             </select>
           </div>
          <input type="hidden" value="<?php echo $isbn;?>" name="isbn" />
          <input type="submit" value="Submit" />
        </form><br><br>
      </div>
    </div>
  </div>
  </body>
</html>
<script>
 function check(input) {
   if (input.value == 0) {
     //input.setCustomValidity('The number must not be zero.');
     input.value=1;
   } else {
     // input is fine -- reset the error message
     //input.setCustomValidity('');
   }
 }
</script>
