<?php
  session_start();
  $fName = $_SESSION['fname'];
  $lName = $_SESSION['lname'];
  $employeeid = $_SESSION['eid'];
  $email = $_SESSION['email'];
  $password = $_SESSION['password'];
 ?>

<!DOCTYPE html>
<html lang="en">
<head>
<title>Admin | User Management</title>
<meta charset="utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1"/>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
</head>

<style>
h1{
  text-align: center;
  margin-bottom: 30px;
}

.active{
  color: black;
  font-weight: bold;
}

.table{
  width: 80%;
  margin: 0 auto;
}

.table_frame{
  margin-top: 20px;
}

.link:hover{
  color: grey;
  text-decoration: none;
}

.link{
  position:relative;
  top:15px;
  left: 1380px;
}

.form-container{
  padding-top: 20px;
  padding-left: 400px;
  padding-right: 400px;
}


.logo-position{
  float:left;
}

.btn{
  background-color: darkgrey;
  border-radius: 5px;
  color:white;
  padding-left:1em;
  padding-right:1em;
}

.btn:hover{
  background-color: grey;
  color:white;
}
</style>

<body>
  <img class="logo" src="images/logo.PNG"/>
  <nav class="navbar navbar-default">
    <!-- the options changes depending on what page the user is on-->
    <div class="collapse navbar-collapse" id="myNavbar">
      <ul class="nav navbar-nav navbar-right">
        <li id="User"><a class="active" href="admin_user_manage.php">Users</a></li>
        <li id="Book"><a href="admin_book_manage.php">Books</a></li>
        <li id="Transaction"><a href="admin_transaction_manage.php">Transactions</a></li>
        <li id="Sales_Report"><a href="admin_sales_report.php">Sales Report&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</a></li>
        <li><a style="color: red;"><?php echo $fName." ".$lName." (eid:".$employeeid.")";?></a></li>
        <li id="Logout"><a href="logout.php">Logout</a></li>
      </ul>
    </div>
  </nav>

	<div class="form-container">
			<h1>Create An Account</h1>
	<form action="create_user.php" id="register_form" method="post">
		<div class="form-group row">
      		<label for="email" class="col-sm-2 col-form-label">Email Address:</label>
      		<input type="email" class="form-control col-sm-10" id="email" name="email" maxlength="50" required>
    	</div>
    	<div class="form-group row">
      		<label for="password" class="col-sm-2 col-form-label">Passowrd:</label>
      		<input type="password" class="form-control col-sm-10" id="password" name="password" maxlength="25" required>
    	</div>
    	<div class="form-group row">
      		<label for="firstname" class="col-sm-2 col-form-label">First Name:</label>
      		<input type="text" class="form-control col-sm-10" id="firstname" name="firstname" maxlength="45" required>
    	</div>
    	<div class="form-group row">
      		<label for="lastname" class="col-sm-2 col-form-label">Last Name:</label>
      		<input type="text" class="form-control col-sm-10" id="lastname" name="lastname" maxlength="45" required>
    	</div>
    	<div class="form-group row">
      		<label for="phone" class="col-sm-2 col-form-label">Phone:</label>
      		<input type="number" class="form-control col-sm-10" id="phone" name="phone" minlength="10" maxlength="12">
    	</div>
      <div class="form-group row">
          <label for="street" class="col-sm-2 col-form-label">Street:</label>
          <input type="text" class="form-control col-sm-10" id="street" name="street" maxlength="50">
      </div>
      <div class="form-group row">
          <label for="city" class="col-sm-2 col-form-label">City:</label>
          <input type="text" class="form-control col-sm-10" id="city" name="city" maxlength="50">
      </div>
      <div class="form-group row">
          <label for="state" class="col-sm-2 col-form-label">State:</label>
          <input type="text" class="form-control col-sm-10" id="state" name="state" maxlength="25">
      </div>
      <div class="form-group row">
          <label for="zip" class="col-sm-2 col-form-label">Zip:</label>
          <input type="number" class="form-control col-sm-10" id="zip" name="zip" maxlength="15">
      </div>
    	<div class="form-group">
      		<button type="submit" class="btn">Create</button>
    	</div>
	</form>
</div>
  </body>

</html>
