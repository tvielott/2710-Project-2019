<?php
    // Include the functions page for common functions.
    include_once("includes/common_functions.php");

    // Create a connection to the database
    $conn = connection();
    session_start();
    $fName = $_SESSION['fname'];
    $lName = $_SESSION['lname'];
    $employeeid = $_SESSION['eid'];
    $email = $_SESSION['email'];
    $password = $_SESSION['password'];

    $result=mysqli_query( $conn, "SELECT * FROM Employees, Users WHERE Email = '".$email."' AND Password = '".$password."' AND Employees.uid = Users.uid") or die("Could not execute query: " .mysqli_error($conn));
    $row = mysqli_fetch_assoc($result);

  	if($row == ""){
      echo "Unauthorized Access!";
  		header("refresh:3; url=index.html");
  		exit;
  	}

    $uid = $_GET["uid"];
    $result=mysqli_query( $conn, "SELECT * FROM Users WHERE uid = '".$uid."'") or die("Could not execute query: " .mysqli_error($conn));
    $row = mysqli_fetch_assoc($result);
 ?>

<!DOCTYPE html>
<html lang="en">
<head>
<title>Admin | User Management</title>
<meta charset="utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1"/>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>

<style>
.active{
  color: black;
  font-weight: bold;
}

.form{
  width: 80%;
  margin: 0 auto;
}

.table{
  width: 60%;
}

button{
  border: solid 1px grey;
}
</style>
</head>
<body>
  <img class="logo" src="images/logo.PNG"/>
  <nav class="navbar navbar-default">
    <!-- the options changes depending on what page the user is on-->
    <div class="collapse navbar-collapse" id="myNavbar">
      <ul class="nav navbar-nav navbar-right">
        <li id="User"><a class="active" href="admin_user_manage.php">Users</a></li>
        <li id="Book"><a href="admin_book_manage.php">Books</a></li>
        <li id="Transaction"><a href="admin_transaction_manage.php">Transactions</a></li>
        <li id="Sales_Report"><a href="admin_sales_report.php">Sales Report&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</a></li>
        <li><a style="color: red;"><?php echo $fName." ".$lName." (eid:".$employeeid.")";?></a></li>
        <li id="Logout"><a href="logout.php">Logout</a></li>
      </ul>
    </div>
  </nav>

  <form action="./update_user.php?uid=<?php echo $row['uid']?>" id="user_form" class="form" method="post">
    <div class="form-group row">
          <label for="email" class="col-sm-2 col-form-label">Email Address:</label>
          <input type="email" class="form-control col-sm-10" id="email" name="email" maxlength="50" value="<?php echo $row['email']?>" required>
      </div>
      <div class="form-group row">
          <label for="firstname" class="col-sm-2 col-form-label">First Name:</label>
          <input type="text" class="form-control col-sm-10" id="firstname" name="firstname" maxlength="45" value="<?php echo $row['fName']?>" required>
      </div>
      <div class="form-group row">
          <label for="lastname" class="col-sm-2 col-form-label">Last Name:</label>
          <input type="text" class="form-control col-sm-10" id="lastname" name="lastname" maxlength="45" value="<?php echo $row['lName']?>" required>
      </div>
      <div class="form-group row">
          <label for="phone" class="col-sm-2 col-form-label">Phone:</label>
          <input type="text" class="form-control col-sm-10" id="phone" name="phone" minlength="10" maxlength="12" value="<?php echo $row['phone']?>" >
      </div>
      <div class="form-group row">
<?php
  $result2 = mysqli_query( $conn, "SELECT Addresses.street, Cities.cname, Cities.state, Addresses.zip FROM Addresses, Users, Cities WHERE Addresses.uid = '".$uid."' AND Addresses.uid = Users.uid AND Addresses.cid = Cities.cid") or die("Could not execute query: " .mysqli_error($conn));
  if($result2){
?>
        <label for="address" class="col-sm-2 col-form-label">Address:</label>
        <table class="table">
          <thead>
            <tr>
              <th>Street</th>
              <th>City</th>
              <th>State</th>
              <th>Zip Code</th>
            </tr>
          </thead>
<?php
  }
  echo "<tbody>";
  while ($row2 = mysqli_fetch_row($result2)){
?>
          <tbody>
            <tr>
              <th><?php echo $row2[0]?></th>
              <th><?php echo $row2[1]?></th>
              <th><?php echo $row2[2]?></th>
              <th><?php echo $row2[3]?></th>
            </tr>
          </tbody>
<?php
  }
  echo "</tbody></table>";
?>
      </div>
      <div class="form-group">
          <button type="submit" class="btn btn-secondary">Update</button>
          <a href="./delete_user.php?uid=<?php echo $row['uid']?>" class="btn btn-secondary">Delete</button>
      </div>
  </form>

</body>

</html>
